<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Connections extends Widget
{

	public function __construct() 
  	{
        parent::widget ();

    }

    function run()
    {
        // Logic will be written here.
	}
} 