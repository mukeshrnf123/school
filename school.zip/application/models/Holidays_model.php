<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Holidays_model extends CI_Model {

    function __construct() 
    {
        $this->tbl = 'tbl_holidays';
    }

    function insert( $data = array() ) 
    {
        $insert = $this->db->insert( $this->tbl, $data );
        if( $insert ) 
        {
            return $this->db->insert_id();
        } 
        else 
        {
            return false;
        }
    }

    function edit( $data = array() ) 
    {
        $this->db->where('id', $data['id']);
        $update = $this->db->update( $this->tbl, $data );
        if( $update ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    function delete( $id ) 
    {
        $update = $this->db->delete($this->tbl, array('id' => $id));
        if( $update ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    function holidaylist( $limit, $start )
    {
        $query = $this->db->query("SELECT id, holiday_name, holiday_start, holiday_end, CASE status WHEN '1' THEN 'Enabled' ELSE 'Disabled' END AS status FROM `" . $this->tbl . "` LIMIT $start, $limit");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }            
        }
        return $data;
    }

    function details( $id )
    {
        $query = $this->db->query("SELECT id, holiday_name, holiday_start, holiday_end, status FROM `" . $this->tbl . "` WHERE id = '" . $id . "' LIMIT 0, 1");
        $result='';
        if ($query -> num_rows() > 0) 
        {
            $result =  $query->row();           
        }
        return $result;
    }

    function record_count() 
    {
        return $this->db->count_all( $this->tbl );
    }

    function holidays_dashboard(){
        $query = $this->db->query("
            SELECT id, 
                holiday_name, 
                DATE_FORMAT( holiday_start, '%d %M %Y' ) AS holiday_date 
            FROM  `" . $this->tbl . "` 
            WHERE DATE_FORMAT( holiday_start, '%y' ) = DATE_FORMAT( NOW(), '%y' ) 
                AND status = 1 
            ORDER BY DATE_FORMAT( holiday_start, '%m' ), 
                DATE_FORMAT( holiday_start, '%d' ) 
        ");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }            
        }
        return $data;
    }
}