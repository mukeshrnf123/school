<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teacher_timetable_model extends CI_Model
{
    
    public function __construct()
    {
        $this->tbl = 'tbl_teacher_timetable';
    }
    
    function insert($data = array())
    {
        $insert = $this->db->insert($this->tbl, $data);
        if ($insert) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }
    
    function edit($data = array())
    {
        $this->db->where('id', $data['id']);
        $update = $this->db->update($this->tbl, $data);
        if ($update) {
            return true;
        } else {
            return false;
        }
    }
    
    public function record_count()
    {
        return $this->db->count_all($this->tbl);
    }
    
    function delete($id)
    {
        $update = $this->db->delete($this->tbl, array(
            'id' => $id
        ));
        if ($update) {
            return true;
        } else {
            return false;
        }
    }
    
    
    function delete_children($id)
    {
        $update = $this->db->delete($this->tbl, array(
            'student_id' => $id
        ));
        if ($update) {
            return true;
        } else {
            return false;
        }
    }
    
    function get_children_count($parent_id)
    {
        $query = $this->db->query("SELECT count( * ) AS children_count FROM `tbl_parent_children` as pc left join tbl_users as u on u.id = pc.student_id where pc.parent_id = '" . $parent_id . "' and u.status = 1")
                ->row()
                ->children_count;
        return $query;
    }
    
    public function teacher_timetable($limit, $start)
    {
        $query = $this->db->query("
            SELECT 
                l.id AS id,
                CONCAT(u.first_name, ' ', u.last_name) AS teacher_name, 
                s.section_name AS section_name, 
                CONCAT(l.lecture_start, ' to ', l.lecture_end) AS lecture, 
                CASE tt.day_id 
                    WHEN 1 THEN 'Monday' 
                    WHEN 2 THEN 'Tuesday' 
                    WHEN 3 THEN 'Wednesday' 
                    WHEN 4 THEN 'Thursday' 
                    WHEN 5 THEN 'Friday' 
                    WHEN 6 THEN 'Saturday' 
                    WHEN 7 THEN 'Sunday' 
                end AS day 
            FROM `" . $this->tbl . "` AS tt 
                LEFT JOIN tbl_users AS u 
                    ON u.id = tt.teacher_id 
                LEFT JOIN tbl_sections AS s 
                    ON s.id = tt.section_id 
                LEFT JOIN tbl_lectures AS l 
                    ON l.id = tt.lecture_id 
                LIMIT  $start, $limit 
        ");
        $data  = array();
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
        }
        return $data;
    }

    function check_timetable( $teacher_id, $section_id, $lecture_id, $day_id )
    {        
        $time_slot_count = $this->db->query("SELECT COUNT(*) AS timetable_count 
                FROM   `" . $this->tbl . "` 
                WHERE  `section_id` = '".$section_id."' 
                    AND `lecture_id` = '".$lecture_id."' 
                    AND `day_id` = '".$day_id."' "
            )
            ->row_array(); 
        
        $teacher_table_count = $this->db->query("SELECT COUNT(*) AS teacher_table_count 
                FROM   `" . $this->tbl . "` 
                WHERE  `teacher_id` = '".$teacher_id."' 
                    AND `lecture_id` = '".$lecture_id."' 
                    AND `day_id` = '".$day_id."' "
            )
            ->row_array(); 
        
        if($time_slot_count['timetable_count'] == 0 && $teacher_table_count['teacher_table_count'] == 0)
        {
            $data = array(
                'teacher_id' => $teacher_id,
                'section_id' => $section_id,
                'lecture_id' => $lecture_id,
                'day_id'     => $day_id,
            );
            
            $save_record = $this->insert($data);
            
            if($save_record)
            {
                echo 'success';die;
            }
            else 
            {
                echo 'On saving data something wrong.';die;
            }
        } 
        
        if( $teacher_table_count['teacher_table_count'] > 0 && $time_slot_count['timetable_count'] > 0 ) 
        {
            echo 'error1';die;
        }
        
        if( $time_slot_count['timetable_count'] > 0 ) 
        {
            echo 'error2';die;
        }
        
        if( $teacher_table_count['teacher_table_count'] > 0 ) 
        {
            echo 'error3';die;
        }       
    }
}