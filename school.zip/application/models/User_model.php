<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model 
{

    public $username;
    public $password;

    function __construct() 
    {
        $this->userTbl = 'tbl_users';
    }

    function authenticate( $username, $password )
    {
        $query = $this->db->query( "SELECT id, username, password FROM `" . $this->userTbl . "` WHERE username = '" . $username . "' AND password = '" . $password . "' LIMIT 0,1");
        $row = $query->row();
        if ( $query->num_rows() == 1 ) 
        {
            return $row;
        } 
        else 
        {
            return false;
        }
    }

    /*public function insert( $data = array() ) {
        if( !array_key_exists( "created", $data ) ) {
            $data['created'] = date( "Y-m-d H:i:s" );
        }
        if( !array_key_exists( "modified", $data ) ) {
            $data['modified'] = date("Y-m-d H:i:s");
        }
        $insert = $this->db->insert( $this->userTbl, $data );
        if( $insert ) {
            return $this->db->insert_id();;
        } else {
            return false;
        }
    }*/

    function insert( $data = array() ) 
    {
        $insert = $this->db->insert( $this->userTbl, $data );
        if( $insert ) 
        {
            return $this->db->insert_id();
        } 
        else 
        {
            return false;
        }
    }

    function userslist( $limit, $start )
    {
        $query = $this->db->query("
                SELECT p.id AS id,
                       p.username  AS username,
                       p.first_name AS first_name,
                       p.last_name  AS last_name, 
                       p.mobile     AS mobile, 
                       p.email      AS email,
                       r.role_name  AS role_name,  
                       CASE p.status 
                         WHEN '1' THEN 'Enabled' 
                         ELSE 'Disabled' 
                       end AS status 
                FROM   `" . $this->userTbl . "` AS p 
                LEFT JOIN `tbl_roles` AS r
                ON p.role_id = r.id
                 
        ");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }           
        }
        return $data;
    }

    function edit( $data = array() ) 
    {
        $this->db->where('id', $data['id']);
        $update = $this->db->update( $this->userTbl, $data );
        if( $update ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    function delete( $id ) 
    {
        $update = $this->db->delete( $this->userTbl, array('id' => $id));
        if( $update ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    function check_unique_username( $id = '', $username ) 
    {
        $this->db->where('username', $username);
        if($id) 
        {
            $this->db->where_not_in('id', $id);
        }
        return $this->db->get( $this->userTbl )->num_rows();
    }

    function record_count() 
    {
        return $this->db->count_all( $this->userTbl );
    }

    function record_count_type($val) 
    {
        $this->db->select ( 'COUNT(*) AS `numrows`' );
        $this->db->where ( array (
                'role_id' => $val
        ) );
        $query = $this->db->get ( $this->userTbl );
        return $query->row ()->numrows;
    }
    /* for user list on the id basis */
    function userslist_type( $limit, $start, $id )
    {
        $query = $this->db->query("
                SELECT p.id AS id,
                       p.username  AS username,
                       p.first_name AS first_name,
                       p.last_name  AS last_name, 
                       p.mobile     AS mobile, 
                       p.email      AS email,
                       r.role_name  AS role_name,  
                       CASE p.status 
                         WHEN '1' THEN 'Enabled' 
                         ELSE 'Disabled' 
                       end AS status 
                FROM   `" . $this->userTbl . "` AS p 
                LEFT JOIN `tbl_roles` AS r
                ON p.role_id = r.id
                WHERE p.role_id = '" . $id . "' 
                LIMIT  $start, $limit 
        ");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }            
        }
        return $data;
    }
    /** for the list of the students */
    function studentslist_type( $limit, $start, $id )
    {
        $query = $this->db->query("
                SELECT p.id AS id,
                       p.username  AS username,
                       p.first_name AS first_name,
                       p.last_name  AS last_name,
                       pc.parent_id AS parent_id,
                       p.mobile     AS mobile, 
                       p.email      AS email,
                       r.role_name  AS role_name,
                       s.section_name  AS section_name,
                       c.class_name  AS class_name,  
                  CASE p.status 
                     WHEN '1' THEN 'Enabled' 
                       ELSE 'Disabled' 
                     end AS status 
                  FROM   `" . $this->userTbl . "` AS p 
                  LEFT JOIN `tbl_roles` AS r
                    ON p.role_id = r.id
                  LEFT JOIN `tbl_student_section` AS ss
                    ON ss.student_id = p.id
                  LEFT JOIN `tbl_sections` AS s
                    ON ss.section_id = s.id
                  LEFT JOIN `tbl_classes` AS c
                    ON s.class_id = c.id
                  LEFT JOIN `tbl_parent_children` AS pc
                    ON pc.student_id = p.id
                  WHERE p.role_id = '" . $id . "' 
                    LIMIT  $start, $limit 
        ");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }            
        }
        return $data;
    }
    
    function details( $id )
    {  
        $query = $this->db->query("
            SELECT u.id          AS id, 
               u.first_name  AS first_name, 
               u.last_name   AS last_name, 
               u.mobile      AS mobile, 
               u.email       AS email, 
               u.username    AS username, 
               u.role_id     AS role_id,
               u.gender      AS gender,
               u.dob         AS dob, 
               u.status      AS status, 
               ss.section_id AS section_id ,
               c.id          AS class_id
            FROM   `" . $this->userTbl . "` AS u 
               LEFT JOIN `tbl_roles` AS r 
                  ON r.id = u.role_id 
               LEFT JOIN `tbl_student_section` AS ss 
                  ON ss.student_id = u.id 
               LEFT JOIN `tbl_sections` AS s 
                  ON s.id = ss.section_id
               LEFT JOIN `tbl_classes` AS c 
                  ON s.class_id = c.id  
            WHERE  u.id = '" . $id . "' 
            LIMIT  0, 1 
        ");
        if ($query -> num_rows() > 0) 
        {
            $result =  $query->row();
            return $result;
        }
        return false;
    }

    function get_students_section_wise( $section_id, $parent_id ) 
    {
      $query = $this->db->query("
        SELECT u.id         AS id, 
          u.first_name AS first_name, 
          u.last_name  AS last_name 
        FROM   tbl_users AS u 
        LEFT JOIN tbl_student_section AS ss 
            ON ss.student_id = u.id 
        WHERE  ss.section_id = '" . $section_id . "' 
          AND u.status = 1 
          AND u.role_id = 4 
          AND u.id 
      ");
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
    /* To get the list of childrens of the parent*/
    function get_children_list_for_parent( $id ) 
    {
      $query = $this->db->query("
        SELECT u.id           AS id, 
           u.first_name   AS first_name, 
           u.last_name    AS last_name, 
           u.email        AS email, 
           u.mobile       AS mobile, 
           s.section_name AS section_name, 
           c.class_name   AS class_name 
        FROM   tbl_parent_children AS pc 
           LEFT JOIN tbl_users AS u 
              ON pc.student_id = u.id 
           LEFT JOIN tbl_student_section AS ss 
              ON ss.student_id = u.id 
           LEFT JOIN tbl_sections AS s 
              ON s.id = ss.section_id 
           LEFT JOIN tbl_classes AS c 
              ON c.id = s.class_id 
        WHERE  pc.parent_id = '" . $id . "' 
               AND u.status = 1 
      ");
      $data = array();
      if ($query->num_rows() > 0) 
      {
          foreach ($query->result() as $row) 
          {
              $data[] = $row;
          }
          return $data;
      }
      return $data;
    }

    function get_parent_name( $id ) 
    {
        $query = $this->db->query( "SELECT first_name, last_name FROM `" . $this->userTbl . "` WHERE id = '" . $id . "' LIMIT 0, 1");
        $row = $query->row();
        if ( $query->num_rows() == 1 ) 
        {
            return $row;
        } 
        else 
        {
            return false;
        }
    }

    function teacher_details( $id )
    {  
        $query = $this->db->query("
            SELECT u.id          AS id, 
              u.first_name  AS first_name, 
              u.last_name   AS last_name, 
              u.mobile      AS mobile, 
              u.email       AS email, 
              u.username    AS username, 
              CASE u.gender 
                WHEN 1 THEN 'Male' 
                WHEN 2 THEN 'Female'  
              end AS gender,
                DATE_FORMAT( u.dob, '%d %M %Y') AS dob, 
               u.created     AS created, 
               u.status      AS status
            FROM   `" . $this->userTbl . "` AS u 
               LEFT JOIN `tbl_roles` AS r 
                  ON r.id = u.role_id 
               LEFT JOIN `tbl_student_section` AS ss 
                  ON ss.student_id = u.id 
               LEFT JOIN `tbl_sections` AS s 
                  ON s.id = ss.section_id
               LEFT JOIN `tbl_classes` AS c 
                  ON s.class_id = c.id  
            WHERE  u.id = '" . $id . "' 
            LIMIT  0, 1 
        ");
        if ($query -> num_rows() > 0) 
        {
            $result =  $query->row();
            return $result;
        }
        return false;
    }

    function teachers()
    {
        $query = $this->db->query("
                SELECT p.id AS id,
                       p.first_name AS first_name,
                       p.last_name  AS last_name 
                FROM   `" . $this->userTbl . "` AS p 
                WHERE p.role_id = 3 
                AND p.status = 1 
        ");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }            
        }
        return $data;
    }

    function usertypes_dashboard()
    {
        $query = $this->db->query("
          SELECT CONCAT('Total ', r.role_name, 's') AS label, 
                 COUNT(u.role_id)                   AS value 
          FROM   `tbl_users` AS u 
                 LEFT JOIN tbl_roles AS r 
                        ON r.id = u.role_id 
          WHERE  u.status = 1 
                 AND u.role_id <> 1 
          GROUP  BY u.role_id 
      ");
      $data = array();
      if ($query->num_rows() > 0) 
      {
          foreach ($query->result() as $row) 
          {
              $data[] = $row;
          }            
      }
      return json_encode($data);
    }
}