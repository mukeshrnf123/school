<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Students_model extends CI_Model {

    function __construct() {
        $this->tbl = 'tbl_users';
    }

    public function insert( $data = array() ) {
        $insert = $this->db->insert( $this->tbl, $data );
        if( $insert ) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    public function edit( $data = array() ) {
        $this->db->where('id', $data['id']);
        $update = $this->db->update( $this->tbl, $data );
        if( $update ) {
            return true;
        } else {
            return false;
        }
    }

    public function delete( $id ) {
        $update = $this->db->delete($this->tbl, array('id' => $id));
        if( $update ) {
            return true;
        } else {
            return false;
        }
    }

    public function get_user_id( $id ) {
        $result = $this->db->select('user_id')
            ->from('tbl_parents')
            ->where('id', $id)
            ->limit(1)
            ->get()
            ->row();
        if( $result->user_id ) {
            return $result->user_id;
        } else {
            return false;
        }
    }

    public function studentslist( $limit, $start )
    {
        $query = $this->db->query("
            SELECT * FROM `".$this->tbl."`
            LIMIT  $start, $limit 
            ");
        $data = array();
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }            
        }
        return $data;
    }

    public function details( $id )
    {  
        $query = $this->db->query("
            SELECT p.id AS id,
                   p.user_id AS user_id, 
                   p.first_name AS first_name, 
                   p.last_name  AS last_name, 
                   p.mobile     AS mobile, 
                   p.email      AS email, 
                   u.username   AS username 
            FROM   `tbl_parents` AS p 
                   LEFT JOIN `tbl_users` AS u 
                          ON u.id = p.user_id 
            WHERE  p.id = '" . $id . "'
            LIMIT  0, 1 
            ");
        if ($query -> num_rows() > 0) {
            $result =  $query->row();
            return $result;
        }
        return false;
    }

    public function record_count() {
        $this->db->where('id', $data['id']);
        return $this->db->count_all( $this->tbl );
    }
}