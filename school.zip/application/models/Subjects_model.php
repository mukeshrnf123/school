<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subjects_model extends CI_Model {

    function __construct() {
        $this->tbl = 'tbl_subjects';
    }

    function insert( $data = array() ) {
        $insert = $this->db->insert( $this->tbl, $data );
        if( $insert ) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function edit( $data = array() ) {
        $this->db->where('id', $data['id']);
        $update = $this->db->update( $this->tbl, $data );
        if( $update ) {
            return true;
        } else {
            return false;
        }
    }

    function delete( $id ) {
        $update = $this->db->delete($this->tbl, array('id' => $id));
        if( $update ) {
            return true;
        } else {
            return false;
        }
    }

    function subjectlist( $limit, $start )
    {
        $for_limit = '';
        if($limit) {
            $for_limit = 'LIMIT ' . $start . ','. $limit;
        } else {
            $for_limit = 'WHERE s.status = 1';
        }
        $query = $this->db->query("SELECT s.id AS id, s.subject_name AS subject_name, CASE s.status WHEN '1' THEN 'Enabled' ELSE 'Disabled' END AS status FROM `" . $this->tbl . "` AS s $for_limit");
        $data = array();
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }            
        }
        return $data;
    }

    function details( $id )
    {
        $query = $this->db->query("SELECT id, subject_name, status FROM `" . $this->tbl . "` LIMIT 0, 1");
        $result='';
        if ($query -> num_rows() > 0) {
            $result =  $query->row();           
        }
        return $result;
    }

    function record_count() {
        return $this->db->count_all( $this->tbl );
    }
}