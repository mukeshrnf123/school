<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Roles_model extends CI_Model {

    function __construct() {
        $this->tbl = 'tbl_roles';
    }

    public function insert( $data = array() ) {
        $insert = $this->db->insert( $this->tbl, $data );
        if( $insert ) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    public function edit( $data = array() ) {
        $this->db->where('id', $data['id']);
        $update = $this->db->update( $this->tbl, $data );
        if( $update ) {
            return true;
        } else {
            return false;
        }
    }

    public function delete( $id ) {
        $update = $this->db->delete($this->tbl, array('id' => $id));
        if( $update ) {
            return true;
        } else {
            return false;
        }
    }

    public function rolelist( $limit, $start )
    {
        $query = $this->db->query("SELECT id, class_name, CASE status WHEN '1' THEN 'Enabled' ELSE 'Disabled' END AS status FROM `" . $this->tbl . "` LIMIT $start, $limit");
        $data = array();
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }           
        }
        return $data;
    }

    public function details( $id )
    {
        $query = $this->db->query("SELECT id, class_name, status FROM `" . $this->tbl . "` WHERE id ='".$id."' LIMIT 0,1");
        if ($query -> num_rows() > 0) {
            $result =  $query->row();
            return $result;
        }
        return false;
    }

    public function record_count() {
        return $this->db->count_all( $this->tbl );
    }

    public function rolelists()
    {
        $query = $this->db->query("SELECT id, role_name, status FROM `" . $this->tbl . "` WHERE status = 1");
        $data = array();
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }            
        }
        return $data;
    }

    function check_unique_class_name( $id = '', $class_name ) {
        $this->db->where('class_name', $class_name);
        if($id) {
            $this->db->where_not_in('id', $id);
        }
        return $this->db->get( $this->tbl )->num_rows();
    }
}