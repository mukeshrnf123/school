<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attendences_model extends CI_Model {

    function __construct() 
    {
        $this->tbl = 'tbl_attendence';
    }

    function insert( $data = array() ) 
    {
        $insert = $this->db->insert( $this->tbl, $data );
        if( $insert ) 
        {
            return $this->db->insert_id();
        } 
        else 
        {
            return false;
        }
    }

    function edit( $data = array() ) 
    {
        $this->db->where('id', $data['id']);
        $update = $this->db->update( $this->tbl, $data );
        if( $update ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    function delete( $id ) 
    {
        $update = $this->db->delete($this->tbl, array('id' => $id));
        if( $update ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    function holidaylist( $limit, $start )
    {
        $query = $this->db->query("SELECT id, holiday_name, holiday_start, holiday_end, CASE status WHEN '1' THEN 'Enabled' ELSE 'Disabled' END AS status FROM `" . $this->tbl . "` LIMIT $start, $limit");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }            
        }
        return $data;
    }

    function details( $id )
    {
        $query = $this->db->query("SELECT id, holiday_name, holiday_start, holiday_end, status FROM `" . $this->tbl . "` WHERE id = '" . $id . "' LIMIT 0, 1");
        $result='';
        if ($query -> num_rows() > 0) 
        {
            $result =  $query->row();           
        }
        return $result;
    }

    function record_count() 
    {
        return $this->db->count_all( $this->tbl );
    }

    function holidays_dashboard(){
        $query = $this->db->query("
            SELECT id, 
                holiday_name, 
                DATE_FORMAT( holiday_start, '%d %M %Y' ) AS holiday_date 
            FROM  `" . $this->tbl . "` 
            WHERE DATE_FORMAT( holiday_start, '%y' ) = DATE_FORMAT( NOW(), '%y' ) 
                AND status = 1 
            ORDER BY DATE_FORMAT( holiday_start, '%m' ), 
                DATE_FORMAT( holiday_start, '%d' ) 
        ");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }            
        }
        return $data;
    }
    
    function insert_batch_for( $data = array() ) 
    {
        $this->db->insert_batch( $this->tbl , $data);
    }
    
    function update_batch_for( $data = array() ) 
    {
        $this->db->trans_start();
        foreach($data as $val){
            $this->db->query("UPDATE `" . $this->tbl . "` SET `attendence` = '" . $val['attendence'] . "' WHERE student_id = '" . $val['student_id'] . "' AND `current_date` = '" . $val['current_date'] . "' " );
        }
        
        if ($this->db->trans_status() === FALSE)
        {
            $this->db->trans_rollback();
            return false;
        }
        else
        {
            $this->db->trans_commit();
            return true;
        }

    }

    function check_attendence_done( $section_id, $attendence_date )
    {
        $date = date( 'Y-m-d', strtotime( $attendence_date ) );
        $check_attendence = $this->db->query("SELECT a.student_id AS id, 
                CONCAT(u.first_name,' ',u.last_name) AS name, 
                a.section_id AS section_id,
                1 as edit,
                a.attendence AS attendence 
            FROM `tbl_attendence` AS a 
            LEFT JOIN tbl_users AS u 
                ON u.id=a.student_id 
            WHERE a.section_id= '".$section_id."' 
                AND a.current_date = '".$date."'");
        $data = array();
        if ( $check_attendence->num_rows() > 0 ) 
        {
            foreach ( $check_attendence->result() as $row ) 
            {
                $data[] = $row;
            }            
        }
        
        if( count( $data )  > 0 )
        {
            echo json_encode( $data );die;
        }
        else
        {
            return false;
        }
    }
}