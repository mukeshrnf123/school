<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Secstudent_model extends CI_Model {

    function __construct() {
        $this->tbl = 'tbl_student_section';
    }

    function insert( $data = array() ) {
        //die('here');
        $insert = $this->db->insert( $this->tbl, $data );
        if( $insert ) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function edit( $data = array() ) 
    {
        $this->db->where('student_id', $data['student_id']);
        $update = $this->db->update( $this->tbl, $data );
        
        if( $update ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    function delete( $id ) 
    {
        $update = $this->db->delete($this->tbl, array('id' => $id));
        
        if( $update ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    function sectionslist( $limit, $start ) 
    {
        $query = $this->db->query("SELECT s.id AS id, c.class_name AS class_name, s.class_id AS class_id, s.section_name AS section_name, CASE s.status WHEN '1' THEN 'Enabled' ELSE 'Disabled' END AS status FROM `" . $this->tbl . "` AS s LEFT JOIN tbl_classes AS c ON s.class_id = c.id LIMIT $start, $limit");
        $data = array();
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }            
        }
        return $data;
    }

    function details( $id )
    {
        $query = $this->db->query("SELECT s.id AS id, c.class_name AS class_name, s.class_id AS class_id, s.section_name AS section_name, s.status AS status FROM `" . $this->tbl . "` AS s LEFT JOIN tbl_classes AS c ON s.class_id = c.id WHERE s.id = '" . $id . "' LIMIT 0,1");
        if ($query -> num_rows() > 0) {
            $result =  $query->row();
            return $result;
        }
        return false;
    }

    function record_count() {
        return $this->db->count_all( $this->tbl );
    }

    function check_unique_section_name($id = '', $section_name) {
        $this->db->where('section_name', $section_name);
        if($id) {
            $this->db->where_not_in('id', $id);
        }
        return $this->db->get( $this->tbl )->num_rows();
    }

    function check_user( $id ) {
        $query = $this->db->query("SELECT id FROM `" . $this->tbl . "`  WHERE student_id = '" . $id . "' LIMIT 0,1");
        if ($query -> num_rows() > 0) {
            $result =  $query->row();
            return $result;
        }
        return false;
    }
    
    function get_section_class_wise( $class_id ) 
    {
        $query = $this->db->query("SELECT id, 
                    section_name 
                FROM   `" . $this->tbl . "` 
                WHERE  class_id = '". $class_id ."'
            AND status = 1 ");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }
        }
        return $data;
    }

    function get_students_by_section( $section_id )
    {
        $query = $this->db->query("SELECT u.id  AS id, 
            CONCAT(u.first_name, ' ', u.last_name) AS name, ss.section_id AS section_id
        FROM   `tbl_student_section` AS ss 
               LEFT JOIN tbl_users AS u 
                      ON u.id = ss.student_id 
        WHERE  ss.section_id = '" . $section_id . "' 
               AND u.status = 1");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }            
        }
        return $data;
    }
}