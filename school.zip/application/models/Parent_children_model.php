<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parent_children_model extends CI_Model 
{

    public function __construct() 
    {
        $this->tbl = 'tbl_parent_children';
    }

    function insert( $parent_id, $childrens  ) 
    {
        $childrens_list = explode(',', $childrens);
        
        $query = 'INSERT INTO `' . $this->tbl . '` (`parent_id`, `student_id`) VALUES ';
        $query_parts = array();
        
        for($x = 0; $x < count($childrens_list); $x++)
        {
            $query_parts[] = "('" . $parent_id . "', '" . $childrens_list[$x] . "')";
        }

        $query .= implode(', ', $query_parts);
        $run_query = $this->db->query($query);

        if( $run_query ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    function delete( $id ) 
    {
        $update = $this->db->delete($this->tbl, array('id' => $id));
        if( $update ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    
    function delete_children( $id ) 
    {
        $update = $this->db->delete($this->tbl, array('student_id' => $id));
        if( $update ) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    function get_children_count( $parent_id ) 
    {
        $query = $this->db->query( "SELECT count( * ) AS children_count FROM `tbl_parent_children` as pc left join tbl_users as u on u.id = pc.student_id where pc.parent_id = '" . $parent_id . "' and u.status = 1")->row()->children_count;
       // $children_count = $query->get()->row('children_count');
        return $query;
    }

    /* To check children is exist or not */
    function check_children_lists( $childrens_lists )
    {
        $query = $this->db->query("SELECT student_id FROM `" . $this->tbl . "` where student_id in (". $childrens_lists .")");
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }            
        }
        //echo json_encode($data);die;
        return json_encode($data);
    }
}