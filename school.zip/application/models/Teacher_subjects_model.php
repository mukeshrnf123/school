<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teacher_subjects_model extends CI_Model
{
    
    public function __construct()
    {
        $this->tbl = 'tbl_teacher_subjects';
    }
    
    function insert( $id, $insert_teacher_subjects )
    {
        $this->db->trans_begin();

        $query_delete = $this->db->query("DELETE FROM `" . $this->tbl . "` WHERE teacher_id = '" . $id . "'");

        $query = 'INSERT INTO `' . $this->tbl . '` (`teacher_id`, `subject_id`) VALUES ';
        
        $query_parts = array();
        
        for($x=0; $x<count($insert_teacher_subjects); $x++)
        {
            $query_parts[] = "('" . $id . "', '" . $insert_teacher_subjects[$x] . "')";
        }
        $query .= implode(', ', $query_parts);
        $run_query = $this->db->query($query);

        $this->db->trans_complete();

        if( $this->db->trans_status() == true ) 
        {
            $this->db->trans_commit();
            return true;
        } 
        else 
        {
            $this->db->trans_rollback();
            return false;
        }
    }

    function teacher_subjects( $id )
    {

        $query = $this->db->query("
            SELECT GROUP_CONCAT( ts.subject_id )  AS subject_ids, 
                   GROUP_CONCAT( ' ', s.subject_name ) AS subjects_names
            FROM   `" . $this->tbl . "` AS ts 
                   LEFT JOIN tbl_subjects AS s 
                          ON s.id = ts.subject_id 
            WHERE  ts.teacher_id = '" . $id . "' 
            ");
        
        $data = array();
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }           
        }
        return $data;
    }
}