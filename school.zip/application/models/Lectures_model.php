<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lectures_model extends CI_Model {

    function __construct() {
        $this->tbl = 'tbl_lectures';
    }

    public function insert( $data = array() ) {
        $insert = $this->db->insert( $this->tbl, $data );
        if( $insert ) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    public function edit( $data = array() ) {
        $this->db->where('id', $data['id']);
        $update = $this->db->update( $this->tbl, $data );
        if( $update ) {
            return true;
        } else {
            return false;
        }
    }

    public function delete( $id ) {
        $update = $this->db->delete($this->tbl, array('id' => $id));
        if( $update ) {
            return true;
        } else {
            return false;
        }
    }

    public function lecturelist( $limit, $start )
    {
        if( $start != '') {
            $query = $this->db->query("SELECT t.id as id, DATE_FORMAT(`t`.`lecture_start`,'%r') AS `start`,DATE_FORMAT(`t`.`lecture_end`,'%r') AS `end` FROM `tbl_lectures` AS `t` LIMIT $start, $limit");
        } else {
            $query = $this->db->query("SELECT t.id as id, DATE_FORMAT(`t`.`lecture_start`,'%r') AS `start`,DATE_FORMAT(`t`.`lecture_end`,'%r') AS `end` FROM `tbl_lectures` AS `t`");
        }
        
        $data = array();
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }           
        }
        return $data;
    }

    public function details( $id )
    {
        $query = $this->db->query("SELECT t.id as id, DATE_FORMAT(`t`.`lecture_start`,'%r') AS `start`,DATE_FORMAT(`t`.`lecture_end`,'%r') AS `end` FROM `tbl_lectures` AS `t` WHERE id = '" . $id . "'LIMIT 0, 1");
        if ($query -> num_rows() > 0) {
            $result =  $query->row();
            return $result;
        }
        return false;
    }

    public function record_count() {
        return $this->db->count_all( $this->tbl );
    }

    public function rolelists()
    {
        $query = $this->db->query("SELECT id, role_name, status FROM `" . $this->tbl . "` WHERE status = 1");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
}