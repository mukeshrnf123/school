<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Classes extends CI_Controller {

    public function __construct()
    {
		parent::__construct();
		$this->load->model( 'classes_model' );
    }

	public function add() 
	{
		$header['title'] = 'Class Add';
		$this->load->library( 'form_validation' );
				
        $this->form_validation->set_rules( 'class_name', 'Class Name', 'trim|required|xss_clean|is_unique[tbl_classes.class_name]' );

		$classData = array(
			'class_name' => strip_tags( $this->input->post( 'class_name' ) ),
		);

		$data = array();
        if( $this->form_validation->run() == false ) {
			$this->load->view( 'admin/layout/dashboard_header', $header );
			$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
			$this->load->view( 'admin/classes/add', $data );
			$this->load->view( 'admin/layout/dashboard_footer' );	
		} else {	
            $insert = $this->classes_model->insert($classData);
            if( $insert ) {
                $this->session->set_flashdata('success_msg', 'Class is added successfully.');
                redirect( 'admin/classes/add' );
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
	} 

    public function edit() 
	{
		$header['title'] = 'Class Edit';
		$this->load->library( 'form_validation' );
		$id = uri_custom();
        $this->form_validation->set_rules( 'class_name', 'Class Name', 'trim|required|xss_clean|callback_check_class_name' );

		$classData = array(
			'class_name' => strip_tags( $this->input->post( 'class_name' ) ),
			'id' => strip_tags( $this->input->post( 'id' ) ),
			'status' => strip_tags( $this->input->post( 'status' ) ),
		);

		$data = array();

		$data['details'] = $this->classes_model->details( $id );
        if( $this->form_validation->run() == false ) {
			$this->load->view( 'admin/layout/dashboard_header', $header );
			$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
			$this->load->view( 'admin/classes/edit', $data );
			$this->load->view( 'admin/layout/dashboard_footer' );	
		} else {	
            $insert = $this->classes_model->edit($classData);
            if( $insert ) {
                $this->session->set_flashdata('success_msg', 'Class is updated successfully.');
                redirect( 'admin/classes/classlist' );
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
	}

	function check_class_name($class_name) {        
	    if($this->input->post('id'))
	        $id = $this->input->post('id');
	    else
	        $id = '';
	    $result = $this->classes_model->check_unique_class_name($id, $class_name);
	    if($result == 0)
	        $response = true;
	    else {
	        $this->form_validation->set_message('check_class_name', 'Class Name must be unique');
	        $response = false;
	    }
	    return $response;
	}

	public function classlist() {
        $header['title'] = 'Class lists';
        $this->load->library('pagination');  
       
        $config = array();
        $config["base_url"] = base_url() . "admin/classes/classlist";
        $config["total_rows"] = $this->classes_model->record_count();
        $config["per_page"] = 5;
        $config["uri_segment"] = 4;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

        $page = (uri_custom()) ? uri_custom() : 0;
       	$data['results']  = $this->classes_model->classlist($config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();

		$this->load->view( 'admin/layout/dashboard_header', $header );
		$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
		$this->load->view('admin/classes/list', $data);
		$this->load->view( 'admin/layout/dashboard_footer' );
	}

	public function delete( $id ) {
		if( $id != '') {
			$delete = $this->classes_model->delete( $id );
			if( $delete ) {
				$this->session->set_flashdata('success_msg', 'Class is deleted successfully.');
			} else {
				$this->session->set_flashdata('success_err', 'Some problems occured, please try again.');
			}
			redirect( 'admin/classes/classlist' );
		}
	}
}