<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

    public function __construct()
    {
		parent::__construct();
		$this->load->model( 'users_model' );
		$this->load->model( 'roles_model' );               
    }

    public function index()
    {
        $header['title'] = 'Profile';
        $data = array();
        $this->load->view( 'admin/layout/dashboard_header', $header );
        $this->load->view( 'admin/layout/dashboard_sidebar_menu' );
        $this->load->view( 'admin/users/lists', $data );
        $this->load->view( 'admin/layout/dashboard_footer' );
    }

    public function ajax_list()
    {
        $list = $this->users_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $customers->first_name;
            $row[] = $customers->last_name;
            $row[] = $customers->email;
            $row[] = $customers->mobile;
            $row[] = $customers->id;
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->users_model->count_all(),
                        "recordsFiltered" => $this->users_model->count_filtered(),
                        "data" => $data,
                );
        echo json_encode($output);
    }
}