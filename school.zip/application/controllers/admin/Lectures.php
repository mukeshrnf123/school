<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lectures extends CI_Controller {

    public function __construct()
    {
		parent::__construct();
		$this->load->model( 'lectures_model' );
    }

	public function add() 
	{
		$header['title'] = 'Lecture Add';
		$this->load->library( 'form_validation' );		
		
       	$this->form_validation->set_rules( 'lecture_start', 'Lectures Start', 'trim|required|xss_clean' );
        $this->form_validation->set_rules( 'lecture_end', 'Lectures End', 'trim|required|xss_clean' );

		$lecturesData = array(
			'lecture_start' => strip_tags( $this->input->post( 'lecture_start' ) ),
			'id' => strip_tags( $this->input->post( 'id' ) ),
			'lecture_end' => strip_tags( $this->input->post( 'lecture_end' ) ),
		);

		$data = array();
        if( $this->form_validation->run() == false ) {
			$this->load->view( 'admin/layout/dashboard_header', $header );
			$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
			$this->load->view( 'admin/lectures/add', $data );
			$this->load->view( 'admin/layout/dashboard_footer' );	
		} else {	
            $insert = $this->lectures_model->insert($lecturesData);
            if( $insert ) {
                $this->session->set_flashdata('success_msg', 'Lecture is added successfully.');
                redirect( 'admin/lectures/add' );
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
	} 

    public function edit() 
	{
		$header['title'] = 'Lecture Edit';
		$this->load->library( 'form_validation' );
		$id = uri_custom();
        $this->form_validation->set_rules( 'lecture_start', 'Lectures Start', 'trim|required|xss_clean' );
        $this->form_validation->set_rules( 'lecture_end', 'Lectures End', 'trim|required|xss_clean' );

		$lecturesData = array(
			'lecture_start' => strip_tags( $this->input->post( 'lecture_start' ) ),
			'id' => strip_tags( $this->input->post( 'id' ) ),
			'lecture_end' => strip_tags( $this->input->post( 'lecture_end' ) ),
		);

		$data = array();

		$data['details'] = $this->lectures_model->details( $id );
        if( $this->form_validation->run() == false ) {
			$this->load->view( 'admin/layout/dashboard_header', $header );
			$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
			$this->load->view( 'admin/lectures/edit', $data );
			$this->load->view( 'admin/layout/dashboard_footer' );	
		} else {
            $insert = $this->lectures_model->edit($lecturesData);
            if( $insert ) {
                $this->session->set_flashdata('success_msg', 'Lecture is updated successfully.');
                redirect( 'admin/lectures/lectureslist' );
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
	}

	public function lectureslist() {
        $header['title'] = 'Lectures lists';
        $this->load->library('pagination');
        
        $config = array();
        $config["base_url"] = base_url() . "admin/lectures/lectureslist";
        $config["total_rows"] = $this->lectures_model->record_count();
        $config["per_page"] = 5;
        $config["uri_segment"] = 4;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

        $page = (uri_custom()) ? uri_custom() : 0;
       	$data['results']  = $this->lectures_model->lecturelist($config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();

		$this->load->view( 'admin/layout/dashboard_header', $header );
		$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
		$this->load->view('admin/lectures/list', $data);
		$this->load->view( 'admin/layout/dashboard_footer' );
	}

	public function delete( $id ) {
		if( $id != '') {
			$delete = $this->lectures_model->delete( $id );
			if( $delete ) {
				$this->session->set_flashdata('success_msg', 'Lecture is deleted successfully.');
			} else {
				$this->session->set_flashdata('success_err', 'Some problems occured, please try again.');
			}
			redirect( 'admin/lectures/lectureslist' );
		}
	}
}