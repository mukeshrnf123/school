<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Holidays extends CI_Controller {

    public function __construct()
    {
		parent::__construct();
		$this->load->model( 'holidays_model' );
    }

	public function add() 
	{
		$header['title'] = 'Holiday Add';
		$this->load->library( 'form_validation' );
		
        $this->form_validation->set_rules( 'holiday_name', 'Holiday Name', 'trim|required|xss_clean' );

		$holidayData = array(
			'holiday_name' => strip_tags( $this->input->post( 'holiday_name' ) ),
			'holiday_start' => strip_tags( $this->input->post( 'holiday_start' ) ),
			'holiday_end' => strip_tags( $this->input->post( 'holiday_end' ) ),
			'status' => strip_tags( $this->input->post( 'status' ) ),
		);

		$data = array();
        if( $this->form_validation->run() == false ) {
			$this->load->view( 'admin/layout/dashboard_header', $header );
			$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
			$this->load->view( 'admin/holidays/add', $data );
			$this->load->view( 'admin/layout/dashboard_footer' );	
		} else {	
            $insert = $this->holidays_model->insert($holidayData);
            if( $insert ) {
                $this->session->set_flashdata('success_msg', 'Holiday is added successfully.');
                redirect( 'admin/holidays/lists' );
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
	} 

    public function edit() 
	{
		$header['title'] = 'Holiday Edit';
		$this->load->library( 'form_validation' );
		$id = uri_custom();
        $this->form_validation->set_rules( 'holiday_name', 'Holiday Name', 'trim|required|xss_clean' );

		$holidayData = array(
			'holiday_name' => strip_tags( $this->input->post( 'holiday_name' ) ),
			'holiday_start' => strip_tags( $this->input->post( 'holiday_start' ) ),
			'holiday_end' => strip_tags( $this->input->post( 'holiday_end' ) ),
			'status' => strip_tags( $this->input->post( 'status' ) ),
			'id' => strip_tags( $id ),
		);

		$data = array();

		$data['details'] = $this->holidays_model->details( $id );
        if( $this->form_validation->run() == false ) {
			$this->load->view( 'admin/layout/dashboard_header', $header );
			$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
			$this->load->view( 'admin/holidays/edit', $data );
			$this->load->view( 'admin/layout/dashboard_footer' );	
		} else {	
            $insert = $this->holidays_model->edit($holidayData);
            if( $insert ) {
                $this->session->set_flashdata('success_msg', 'Holiday is updated successfully.');
                redirect( 'admin/holidays/lists' );
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
	}

	public function lists() {
        $header['title'] = 'Holidays lists';
        $this->load->library('pagination');
        
        $config = array();
        $config["base_url"] = base_url() . "admin/holidays/lists";
        $config["total_rows"] = $this->holidays_model->record_count();
        $config["per_page"] = 5;
        $config["uri_segment"] = 4;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

        $page = (uri_custom()) ? uri_custom() : 0;
       	$data['results']  = $this->holidays_model->holidaylist($config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();

		$this->load->view( 'admin/layout/dashboard_header', $header );
		$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
		$this->load->view('admin/holidays/list', $data);
		$this->load->view( 'admin/layout/dashboard_footer' );
	}

	public function delete( $id ) {
		if( $id != '') {
			$delete = $this->holidays_model->delete( $id );
			if( $delete ) {
				$this->session->set_flashdata('success_msg', 'Holiday is deleted successfully.');
			} else {
				$this->session->set_flashdata('success_err', 'Some problems occured, please try again.');
			}
			redirect( 'admin/holidays/list' );
		}
	}
}