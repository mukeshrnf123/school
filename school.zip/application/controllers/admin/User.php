<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct()
    {
		parent::__construct();
		$this->load->model( 'user_model' );
		$this->load->model( 'roles_model' );               
    }

    function login() {
    	$header['title'] = 'Login';

		$this->load->library( 'form_validation' );
				
        $this->form_validation->set_rules( 'username', 'Username', 'trim|required' );
        $this->form_validation->set_rules( 'password', 'Password', 'trim|required' );

        if ( $this->form_validation->run() == FALSE ) {
			$this->load->view( 'admin/layout/header', $header );
			$this->load->view( 'admin/user/login' );
			$this->load->view( 'admin/layout/footer' );
        } else {			
			$username = $this->input->post( 'username' );			
			$password = md5( $this->input->post( 'password' ) );
			$result   = $this->user_model->authenticate( $username, $password );
			if( $result == false ) {
				$this->session->set_flashdata('user_not_found', 'Please provide us the right details.');
				$this->load->view( 'admin/user/login' );
				redirect("admin/user/login");
			} else {				
				$logindata = [
					'username' => $username,
					'user_id'  => $result->id,
					'role'     => 'admin'
				];
	         	$this->session->set_userdata($logindata);
	         	$this->session->set_flashdata('welcome', 'Welcome to the dashboard.');
				redirect('admin/dashboard/index');
			}
        }	
	}

	function register() {
		$header['title'] = 'Register';
		$this->load->library( 'form_validation' );
		
        $this->form_validation->set_rules( 'username', 'Username', 'trim|required|xss_clean|is_unique[tbl_users.username]' );
        $this->form_validation->set_rules( 'email', 'Email', 'trim|required|valid_email|xss_clean|is_unique[tbl_users.email]' );
        $this->form_validation->set_rules( 'password', 'Password', 'trim|required|xss_clean' );
        $this->form_validation->set_rules( 'repassword', 'Re-Password', 'trim|required|matches[password]|xss_clean' );

		$userData = array(
			'username' => strip_tags($this->input->post( 'username' )),
			'email'    => strip_tags($this->input->post( 'email', TRUE )),
			'password' => md5($this->input->post( 'password' )),
		);

        if( $this->form_validation->run() == false ) {
			$this->load->view( 'admin/layout/header', $header );
			$this->load->view( 'admin/user/register' );
			$this->load->view( 'admin/layout/footer' );
		} else {	
            $insert = $this->user_model->insert($userData);
            if( $insert ) {
                $this->session->set_userdata('success_msg', 'Your registration was successfully. Please login to your account.');
                redirect( 'admin/user/login' );
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
	} 

	function logout()
	{
		$user_data = $this->session->all_userdata();
		foreach ($user_data as $key => $value) {
			if ($key != 'session_id' && $key != 'ip_address' && $key != 'user_agent' && $key != 'last_activity') {
				$this->session->unset_userdata($key);
			}
		}
		$this->session->sess_destroy();
		redirect('admin/user/login');
	}

	function profile()
	{
		$header['title'] = 'Profile';
		$data = array();
		$this->load->library( 'form_validation' );

		$config['upload_path']          = './uploads/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 100;
		$config['max_width']            = 100;
		$config['max_height']           = 100;
		$this->load->library('upload', $config);

		$user_data = $this->session->all_userdata();
		$username = $user_data['username']; 
		$get_user_info = $this->get_user_info( $username );
		$data['userinfo'] = $get_user_info;
	        
        if( $this->input->post( 'profile_update' ) == 'Submit' ) {
        	//echo '<pre>';print_r($_FILES);
            if( $this->form_validation->run() == false ) { 
            	if($this->input->post( 'password' ) != '') {
            		$userData = array(
						'username' => strip_tags( $this->input->post( 'username' ) ),
						'email'    => strip_tags( $this->input->post( 'email', TRUE ) ),
						'password' => md5( strip_tags( $this->input->post( 'password' ) ) ),
						'modified' => date( "Y-m-d H:i:s" ),
					);
            	} else {
            		$userData = array(
						'username' => strip_tags( $this->input->post( 'username' ) ),
						'email'    => strip_tags( $this->input->post( 'email', TRUE ) ),
						'modified' => date( "Y-m-d H:i:s" ),
					);
            	}

                $data = array('upload_data' => $this->upload->data());
                //$this->load->view('upload_success', $data);

				$this->db->where('id', $this->session->userdata( 'user_id' ) );
				$this->db->update('tbl_users',$userData);

                $this->session->set_userdata('success_profile_update', 'Profile updated successfully.');		
            } else {
            	die('not valid');
            }
        }
		$this->load->view( 'admin/layout/dashboard_header', $header );
		$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
		$this->load->view( 'admin/user/profile', $data );
		$this->load->view( 'admin/layout/dashboard_footer' );		
	}

	function get_user_info( $username ) {
		if( $username == '' ) {
			return false;
		} else {
			$query = $this->db->query( "SELECT id, username, email, password FROM `tbl_users` WHERE username = '" . $username . "' LIMIT 0,1");
			$row = $query->row();
			return $row;	
		}
	}

	function userslist()
    {
        $header['title'] = 'Users lists';

        $this->load->library('pagination');
        
        $config                = array();
        $config["base_url"]    = base_url() . "admin/user/userslist";
        $config["total_rows"]  = $this->user_model->record_count();
        $config["per_page"]    = 5;
        $config["uri_segment"] = 4;
        
        $config['full_tag_open']   = '<ul class="pagination">';
        $config['full_tag_close']  = '</ul>';
        $config['first_link']      = false;
        $config['last_link']       = false;
        $config['first_tag_open']  = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link']       = '&laquo';
        $config['prev_tag_open']   = '<li class="prev">';
        $config['prev_tag_close']  = '</li>';
        $config['next_link']       = '&raquo';
        $config['next_tag_open']   = '<li>';
        $config['next_tag_close']  = '</li>';
        $config['last_tag_open']   = '<li>';
        $config['last_tag_close']  = '</li>';
        $config['cur_tag_open']    = '<li class="active"><a href="#">';
        $config['cur_tag_close']   = '</a></li>';
        $config['num_tag_open']    = '<li>';
        $config['num_tag_close']   = '</li>';
        
        $this->pagination->initialize($config);
        
        $page            = (uri_custom()) ? uri_custom() : 0;
        $data['results'] = $this->user_model->userslist($config["per_page"], $page);
        $data["links"]   = $this->pagination->create_links();
        
        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/user/lists', $data);
        $this->load->view('admin/layout/dashboard_footer');
    }

    function check_username($user_name)
    {
        if ($this->input->post('id'))
            $id = $this->input->post('id');
        else
            $id = '';
        $result = $this->user_model->check_unique_username($id, $user_name);
        if ($result == 0)
            $response = true;
        else {
            $this->form_validation->set_message('check_username', 'Parent Name must be unique');
            $response = false;
        }
        return $response;
    }

    function add()
    {
        $header['title'] = 'User Add';
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('username', 'User Name', 'trim|required|xss_clean|callback_check_username');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|xss_clean');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|valid_email|xss_clean');
        $this->form_validation->set_rules('mobile', 'Mobile', 'trim|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
        $this->form_validation->set_rules('role_id', 'role', 'trim|required|xss_clean');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|xss_clean');
        $this->form_validation->set_rules('dob', 'DOB', 'trim|required|xss_clean');
        
        $data = array();      
        $data['roles'] = $this->roles_model->rolelists();
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/layout/dashboard_header', $header);
            $this->load->view('admin/layout/dashboard_sidebar_menu');
            $this->load->view('admin/user/add', $data);
            $this->load->view('admin/layout/dashboard_footer');
        } else {
            if ($this->input->post( 'username' ) ) {
                $userData = array(
                	'id'  => $this->uri->segment(4),
                    'username' => strip_tags($this->input->post('username')),
                    'gender' => strip_tags($this->input->post('gender')),
                    'dob' => strip_tags($this->input->post('dob')),
                    'role_id' => strip_tags($this->input->post('role_id')),
                    'created' => date("Y-m-d H:i:s"),
                    'modified' => date("Y-m-d H:i:s"),
                    'first_name' => strip_tags($this->input->post('first_name')),
	                'last_name' => strip_tags($this->input->post('last_name')),
	                'email' => strip_tags($this->input->post('email')),
	                'mobile' => strip_tags($this->input->post('mobile')),
	                'password' => md5( $this->input->post( 'password' ) ),
                );
            } 

            $add_user = $this->user_model->insert($userData);
            if ($add_user) {
                $this->session->set_flashdata('success_msg', 'User is added successfully.');
                redirect('admin/user/userslist');
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
    }

    function edit()
    {
        $header['title'] = 'User Edit';
        $this->load->library('form_validation');
        
        $id = uri_custom();
        $this->form_validation->set_rules('username', 'User Name', 'trim|required|xss_clean|callback_check_username');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|xss_clean');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|valid_email|xss_clean');
        $this->form_validation->set_rules('mobile', 'Mobile', 'trim|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|xss_clean');
        $this->form_validation->set_rules('role_id', 'Role', 'trim|required|xss_clean');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|xss_clean');
        $this->form_validation->set_rules('dob', 'DOB', 'trim|required|xss_clean');
        
        $data = array();       
        $data['details'] = $this->user_model->details($id);
        $data['roles'] = $this->roles_model->rolelists();
        
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/layout/dashboard_header', $header);
            $this->load->view('admin/layout/dashboard_sidebar_menu');
            $this->load->view('admin/user/edit', $data);
            $this->load->view('admin/layout/dashboard_footer');
        } else {
            if ($this->input->post( 'username' ) ) {
                $dob_posted = explode('/', $this->input->post('dob'));
                $dob = $dob_posted['2'] . '-' . $dob_posted['0'] . '-' . $dob_posted['1'];
                $userData = array(
                	'id'  => uri_custom(),
                    'username' => strip_tags($this->input->post('username')),
                    'gender' => strip_tags($this->input->post('gender')),
                    'dob' => $dob,
                    'role_id' => strip_tags($this->input->post('role_id')),
                    'modified' => date("Y-m-d H:i:s"),
                    'first_name' => strip_tags($this->input->post('first_name')),
	                'last_name' => strip_tags($this->input->post('last_name')),
	                'email' => strip_tags($this->input->post('email')),
	                'mobile' => strip_tags($this->input->post('mobile')),
	                'status' => strip_tags($this->input->post('status')),
                );
            } 

            if ( $this->input->post( 'password' ) != '' ) {
            	$passData = array(
            		'password' => md5( $this->input->post( 'password' ) ),
        		);
        		$userData = array_merge( $passData, $userData );
            }

            $edit_user = $this->user_model->edit($userData);
            if ($edit_user) {
                $this->session->set_flashdata('success_msg', 'User is updated successfully.');
                redirect('admin/user/userslist');
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
    }
    
    function childrens() {
        $header['title'] = 'Children list';
        $data = array();
        $this->load->model( 'classes_model' );
        $this->load->model( 'parent_children_model' );
        $data['class_lists'] = $this->classes_model->classlists();
        $parent_id = uri_custom();
        $data['children_lists'] = $this->user_model->get_children_list_for_parent( $parent_id );

        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/user/childrens', $data);
        $this->load->view('admin/layout/dashboard_footer');

        if( $this->input->post( 'class_id' ) ) {
            //echo '<pre>';print_r($_POST);die;
            $childrens = $this->input->post( 'childrens' );
            $parent_children_add = $this->parent_children_model->insert($parent_id, $childrens);
            if( $parent_children_add ) {
                $this->session->set_flashdata('success_msg', 'Childrens added successfully.');
                redirect(redirect_same_url()); // function in helper
            } else {
                 $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
    }

    public function parentslist()
    {
        $header['title'] = 'Parents list';
        $this->load->library('pagination');
        $this->load->model( 'parent_children_model' );

        $config                = array();
        $config["base_url"]    = base_url() . "admin/user/parentslist";
        $config["total_rows"]  = $this->user_model->record_count_type(2);
        $config["per_page"]    = 5;
        $config["uri_segment"] = 4;
        
        $config['full_tag_open']   = '<ul class="pagination">';
        $config['full_tag_close']  = '</ul>';
        $config['first_link']      = false;
        $config['last_link']       = false;
        $config['first_tag_open']  = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link']       = '&laquo';
        $config['prev_tag_open']   = '<li class="prev">';
        $config['prev_tag_close']  = '</li>';
        $config['next_link']       = '&raquo';
        $config['next_tag_open']   = '<li>';
        $config['next_tag_close']  = '</li>';
        $config['last_tag_open']   = '<li>';
        $config['last_tag_close']  = '</li>';
        $config['cur_tag_open']    = '<li class="active"><a href="#">';
        $config['cur_tag_close']   = '</a></li>';
        $config['num_tag_open']    = '<li>';
        $config['num_tag_close']   = '</li>';
        
        $this->pagination->initialize($config);
        
        $page            = (uri_custom()) ? uri_custom() : 0;
        $data['results'] = $this->user_model->userslist_type($config["per_page"], $page, 2);
        $data['parent_children_model'] = $this->parent_children_model;

        $data["links"]   = $this->pagination->create_links();
        
        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/user/parentlist', $data);
        $this->load->view('admin/layout/dashboard_footer');
    }
    /* to delete user */
    function delete( $id ) {
        if( $id != '' ) {
            $delete = $this->user_model->delete( $id );
            if( $delete ) {
                $this->session->set_flashdata('success_msg', 'User is deleted successfully.');
            } else {
                $this->session->set_flashdata('success_err', 'Some problems occured, please try again.');
            }
            redirect( 'admin/user/userslist' );
        }
    }
    /* to delete children from tbl_parent_children table */
    function delete_child( $id ) {
        $parent_id = $this->uri->segment(5);
        $this->load->model( 'parent_children_model' );
        if( $id != '' ) {
            $delete = $this->parent_children_model->delete_children( $id );
            if( $delete ) {
                $this->session->set_flashdata('success_msg', 'Children is deleted successfully.');
            } else {
                $this->session->set_flashdata('success_err', 'Some problems occured, please try again.');
            }
           redirect( 'admin/user/childrens/'. $parent_id );
        }
    }

    function studentslist()
    {
        $header['title'] = 'Students list';
        $this->load->library('pagination');
        
        $config                = array();
        $config["base_url"]    = base_url() . "admin/user/studentslist";
        $config["total_rows"]  = $this->user_model->record_count_type(4);
        $config["per_page"]    = 5;
        $config["uri_segment"] = 4;
        
        $config['full_tag_open']   = '<ul class="pagination">';
        $config['full_tag_close']  = '</ul>';
        $config['first_link']      = false;
        $config['last_link']       = false;
        $config['first_tag_open']  = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link']       = '&laquo';
        $config['prev_tag_open']   = '<li class="prev">';
        $config['prev_tag_close']  = '</li>';
        $config['next_link']       = '&raquo';
        $config['next_tag_open']   = '<li>';
        $config['next_tag_close']  = '</li>';
        $config['last_tag_open']   = '<li>';
        $config['last_tag_close']  = '</li>';
        $config['cur_tag_open']    = '<li class="active"><a href="#">';
        $config['cur_tag_close']   = '</a></li>';
        $config['num_tag_open']    = '<li>';
        $config['num_tag_close']   = '</li>';
        
        $this->pagination->initialize($config);
        
        $page            = (uri_custom()) ? uri_custom() : 0;
        $data['results'] = $this->user_model->studentslist_type($config["per_page"], $page, 4);
        $data['userModel'] = $this->user_model;
        $data["links"]   = $this->pagination->create_links();
        
        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/user/studentlist', $data);
        $this->load->view('admin/layout/dashboard_footer');
    }

    function get_students_section_wise() 
    {
        $section_id = $this->input->post( 'section_id' );
        $parent_id = $this->input->post( 'parent_id' );
        $get_students_sectionwise = array();
        if( $section_id ) 
        {
            $get_students_sectionwise = $this->user_model->get_students_section_wise( $section_id, $parent_id );
            if( count( $get_students_sectionwise ) > 0 ) 
            {
                echo json_encode($get_students_sectionwise);die;
            } 
            else 
            {
                return false;
            }
        } 
        else 
        {
            return false;
        } 
    }

    function teacherslist()
    {
        $header['title'] = 'Teachers list';
        $this->load->library('pagination');
        
        $config                = array();
        $config["base_url"]    = base_url() . "admin/user/teacherslist";
        $config["total_rows"]  = $this->user_model->record_count_type(4);
        $config["per_page"]    = 5;
        $config["uri_segment"] = 4;
        
        $config['full_tag_open']   = '<ul class="pagination">';
        $config['full_tag_close']  = '</ul>';
        $config['first_link']      = false;
        $config['last_link']       = false;
        $config['first_tag_open']  = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link']       = '&laquo';
        $config['prev_tag_open']   = '<li class="prev">';
        $config['prev_tag_close']  = '</li>';
        $config['next_link']       = '&raquo';
        $config['next_tag_open']   = '<li>';
        $config['next_tag_close']  = '</li>';
        $config['last_tag_open']   = '<li>';
        $config['last_tag_close']  = '</li>';
        $config['cur_tag_open']    = '<li class="active"><a href="#">';
        $config['cur_tag_close']   = '</a></li>';
        $config['num_tag_open']    = '<li>';
        $config['num_tag_close']   = '</li>';
        
        $this->pagination->initialize($config);
        
        $page            = (uri_custom()) ? uri_custom() : 0;
        $data['results'] = $this->user_model->userslist_type($config["per_page"], $page, 3);
        $data["links"]   = $this->pagination->create_links();
        
        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/user/teacherslist', $data);
        $this->load->view('admin/layout/dashboard_footer');
    }

    function allusers() 
    {
        $results = $this->user_model->userslist(null,null);
//        echo '<pre>';print_r($results);
        echo json_encode($results);die;
    }
}