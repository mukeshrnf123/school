<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attendence extends CI_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('attendences_model');
    }
    
    public function add()
    {        
        $for_attendences = array();
                
        if($this->input->post()) 
        {           
            //echo '<pre>';print_r($_POST);die;
            $posts = $this->input->post(); 
            $section_id = $this->input->post('sectionid');
            
            foreach($posts AS $key => $value) 
            {
                $student_key = explode( '_', $key );
                $for_attendences['section_id'][] = $student_key[3];
                $for_attendences['student_id'][] = $student_key[1];
                $for_attendences['edit'][] = $student_key[5];
                $for_attendences['attendence'][] = $value;
            }
            
            //echo '<pre>';print_r($student_key[5]);
//            echo $student_key[5];die;
            if( $student_key[5] == 0 ) 
            {
                $for_insert = array();
                for( $i = 0;$i < count($for_attendences['student_id']); $i++ )
                {
                    $date = date( 'Y-m-d' );
                    $for_insert[] = array('student_id' => $for_attendences['student_id'][$i], 'attendence' => $for_attendences['attendence'][$i], 'current_date' => $date, 'section_id' => $for_attendences['section_id'][$i] );
                }

                $insert = $this->attendences_model->insert_batch_for($for_insert);
                if( $for_insert ) 
                {
                   $this->session->set_flashdata('success_msg', 'Attendences is added successfully.');
                   redirect_same_url();
                }
            }
            else 
            {
                $for_update = array();
                for( $i = 0;$i < count($for_attendences['student_id']); $i++ )
                {
                    $date = date( 'Y-m-d' );
                    $for_update[] = array('student_id' => $for_attendences['student_id'][$i], 'attendence' => $for_attendences['attendence'][$i], 'current_date' => $date, 'section_id' => $for_attendences['section_id'][$i] );
                }

                $update = $this->attendences_model->update_batch_for($for_update);
                if( $for_update ) 
                {
                   $this->session->set_flashdata('success_msg', 'Attendences is updated successfully.');
                   redirect_same_url();
                }
                else
                {
                   $this->session->set_flashdata('success_msg', 'Attendences is not updated.');
                   redirect_same_url();                    
                }
            }
        }
        $header['title'] = 'Attendence Add';
        $this->load->model( 'classes_model' );
        $data = array();
        $data['class_lists'] = $this->classes_model->classlists();

        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/attendence/add', $data);
        $this->load->view('admin/layout/dashboard_footer');
    }
    
    public function edit()
    {
        $header['title'] = 'Attendence Edit';
        $this->load->library('form_validation');
        $id = uri_custom();
        $this->form_validation->set_rules('holiday_name', 'Holiday Name', 'trim|required|xss_clean');
        
        $holidayData = array(
            'holiday_name' => strip_tags($this->input->post('holiday_name')),
            'holiday_start' => strip_tags($this->input->post('holiday_start')),
            'holiday_end' => strip_tags($this->input->post('holiday_end')),
            'status' => strip_tags($this->input->post('status')),
            'id' => strip_tags($id)
        );
        
        $data = array();
        
        $data['details'] = $this->attendences_model->details($id);
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/layout/dashboard_header', $header);
            $this->load->view('admin/layout/dashboard_sidebar_menu');
            $this->load->view('admin/holidays/edit', $data);
            $this->load->view('admin/layout/dashboard_footer');
        } else {
            $insert = $this->attendences_model->edit($holidayData);
            if ($insert) {
                $this->session->set_flashdata('success_msg', 'Holiday is updated successfully.');
                redirect('admin/holidays/lists');
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
    }
}