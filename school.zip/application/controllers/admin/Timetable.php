<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Timetable extends CI_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('teacher_timetable_model');       
    }
    
    function lists()
    {
        $header['title'] = 'Teachers Timetable list';
        $this->load->library('pagination');
        
        $config                = array();
        $config["base_url"]    = base_url() . "admin/timetable/lists";
        $config["total_rows"]  = $this->teacher_timetable_model->record_count();
        $config["per_page"]    = 5;
        $config["uri_segment"] = 4;
        
        $config['full_tag_open']   = '<ul class="pagination">';
        $config['full_tag_close']  = '</ul>';
        $config['first_link']      = false;
        $config['last_link']       = false;
        $config['first_tag_open']  = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link']       = '&laquo';
        $config['prev_tag_open']   = '<li class="prev">';
        $config['prev_tag_close']  = '</li>';
        $config['next_link']       = '&raquo';
        $config['next_tag_open']   = '<li>';
        $config['next_tag_close']  = '</li>';
        $config['last_tag_open']   = '<li>';
        $config['last_tag_close']  = '</li>';
        $config['cur_tag_open']    = '<li class="active"><a href="#">';
        $config['cur_tag_close']   = '</a></li>';
        $config['num_tag_open']    = '<li>';
        $config['num_tag_close']   = '</li>';
        
        $this->pagination->initialize($config);
        
        $page            = (uri_custom()) ? uri_custom() : 0;
        $data['results'] = $this->teacher_timetable_model->teacher_timetable($config["per_page"], $page);
        
        $data["links"] = $this->pagination->create_links();
        
        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/timetable/lists', $data);
        $this->load->view('admin/layout/dashboard_footer');
    }
    
    function details($id)
    {
        $header['title'] = 'Teachers list';

        $this->load->model('user_model');
        
        $data['results'] = $this->user_model->teacher_details($id);
        
        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/teachers/detail', $data);
        $this->load->view('admin/layout/dashboard_footer');
    }
    
    function add()
    {
        $header['title'] = 'Timetable Add';
        $this->load->library('form_validation');
        
        $this->load->model('user_model');
        $this->load->model('classes_model');
        $this->load->model('lectures_model');
        
        $this->form_validation->set_rules('teacher_id', 'Teacher', 'trim|required|xss_clean');
        $this->form_validation->set_rules('class_id', 'Class', 'trim|required|xss_clean');
        $this->form_validation->set_rules('section_id', 'Section', 'trim|required|xss_clean');
        $this->form_validation->set_rules('lecture_id', 'Lecture', 'trim|required|xss_clean');
        $this->form_validation->set_rules('day_id', 'Day', 'trim|required|xss_clean');
        
        $data             = array();
        $data['teachers'] = $this->user_model->teachers();
        $data['classes']  = $this->classes_model->classlists();
        $data['lectures'] = $this->lectures_model->lecturelist(null, null);
        $data['days']     = array(
            '1' => 'Monday',
            '2' => 'Tuesday',
            '3' => 'Wednesday',
            '4' => 'Thrusday',
            '5' => 'Friday',
            '6' => 'Saturday'
        );
        
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/layout/dashboard_header', $header);
            $this->load->view('admin/layout/dashboard_sidebar_menu');
            $this->load->view('admin/timetable/add', $data);
            $this->load->view('admin/layout/dashboard_footer');
        } else {
            if ($this->input->post('teacher_id')) {

                $timetableData = array(
                    'teacher_id' => strip_tags($this->input->post('teacher_id')),
                    'section_id' => strip_tags($this->input->post('section_id')),
                    'lecture_id' => strip_tags($this->input->post('lecture_id')),
                    'day_id'     => strip_tags($this->input->post('day_id'))
                );
            }
            
            $add_timetable = $this->teacher_timetable_model->insert($timetableData);
            if ($add_timetable) {
                $this->session->set_flashdata('success_msg', 'Time Table is added successfully.');
                redirect('admin/timetable/lists');
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
    }

    function check_timetable()
    {
        $teacher_id = strip_tags($this->input->post('teacher_id'));
        $section_id = strip_tags($this->input->post('section_id'));
        $lecture_id = strip_tags($this->input->post('lecture_id'));
        $day_id     = strip_tags($this->input->post('day_id'));

        $check_timetable  = $this->teacher_timetable_model->check_timetable( $teacher_id, $section_id, $lecture_id, $day_id );

    }
}