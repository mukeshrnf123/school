<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parents extends CI_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('parents_model');
        $this->load->model('user_model');
    }
    
    public function add()
    {
        $header['title'] = 'Parent Add';
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('user_name', 'User Name', 'trim|required|xss_clean|is_unique[tbl_users.username]');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|xss_clean');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|valid_email|xss_clean');
        $this->form_validation->set_rules('mobile', 'Mobile', 'trim|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
        
        $data = array();
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/layout/dashboard_header', $header);
            $this->load->view('admin/layout/dashboard_sidebar_menu');
            $this->load->view('admin/parents/add', $data);
            $this->load->view('admin/layout/dashboard_footer');
        } else {
            $userData    = array(
                'username' => strip_tags($this->input->post('user_name')),
                'password' => md5(strip_tags($this->input->post('password'))),
                'role_id' => strip_tags($this->input->post('role_id')),
                'created' => date("Y-m-d H:i:s"),
                'modified' => date("Y-m-d H:i:s")
            );
            $insert_user = $this->user_model->insert($userData);
            
            $parentsData   = array(
                'first_name' => strip_tags($this->input->post('first_name')),
                'last_name' => strip_tags($this->input->post('last_name')),
                'email' => strip_tags($this->input->post('email')),
                'mobile' => strip_tags($this->input->post('mobile')),
                'user_id' => $insert_user
            );
            $insert_parent = $this->parents_model->insert($parentsData);
            
            if ($insert_parent) {
                $this->session->set_flashdata('success_msg', 'Parent is added successfully.');
                redirect('admin/parents/parentslist');
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
    }
    
    public function edit()
    {
        $header['title'] = 'Parents Edit';
        $this->load->library('form_validation');
        
        $id = uri_custom();
        $this->form_validation->set_rules('username', 'Parent Name', 'trim|required|xss_clean|callback_check_parent_username');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|xss_clean');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|valid_email|xss_clean');
        $this->form_validation->set_rules('mobile', 'Mobile', 'trim|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|xss_clean');
        
        $data = array();       
        $data['details'] = $this->parents_model->details($id);
        
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/layout/dashboard_header', $header);
            $this->load->view('admin/layout/dashboard_sidebar_menu');
            $this->load->view('admin/parents/edit', $data);
            $this->load->view('admin/layout/dashboard_footer');
        } else {
            if ($this->input->post('password') == '') {
                $userData = array(
                    'username' => strip_tags($this->input->post('username')),
                    'role_id' => strip_tags($this->input->post('role_id')),
                    'modified' => date("Y-m-d H:i:s"),
                    'id' => strip_tags($this->input->post('user_id')),
                );
            } else {
                $userData = array(
                    'username' => strip_tags($this->input->post('username')),
                    'password' => md5(strip_tags($this->input->post('password'))),
                    'modified' => date("Y-m-d H:i:s"),
                    'id' => strip_tags($this->input->post('user_id')),
                );
            }
            $id        = uri_custom();
               
            $parentsData = array(
                'first_name' => strip_tags($this->input->post('first_name')),
                'last_name' => strip_tags($this->input->post('last_name')),
                'email' => strip_tags($this->input->post('email')),
                'id' => strip_tags($this->input->post('id')),
                'mobile' => strip_tags($this->input->post('mobile'))
            );
        
            $edit_user = $this->user_model->edit($userData, $id);
            $edit_parent = $this->parents_model->edit($parentsData, $id);
            if ($edit_parent) {
                $this->session->set_flashdata('success_msg', 'Parent is updated successfully.');
                redirect('admin/parents/parentslist');
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
    }
    
    public function parentslist()
    {
        $header['title'] = 'Parent lists';
        $this->load->library('pagination');
        
        $config                = array();
        $config["base_url"]    = base_url() . "admin/parents/parentslist";
        $config["total_rows"]  = $this->parents_model->record_count();
        $config["per_page"]    = 5;
        $config["uri_segment"] = 4;
        
        $config['full_tag_open']   = '<ul class="pagination">';
        $config['full_tag_close']  = '</ul>';
        $config['first_link']      = false;
        $config['last_link']       = false;
        $config['first_tag_open']  = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link']       = '&laquo';
        $config['prev_tag_open']   = '<li class="prev">';
        $config['prev_tag_close']  = '</li>';
        $config['next_link']       = '&raquo';
        $config['next_tag_open']   = '<li>';
        $config['next_tag_close']  = '</li>';
        $config['last_tag_open']   = '<li>';
        $config['last_tag_close']  = '</li>';
        $config['cur_tag_open']    = '<li class="active"><a href="#">';
        $config['cur_tag_close']   = '</a></li>';
        $config['num_tag_open']    = '<li>';
        $config['num_tag_close']   = '</li>';
        
        $this->pagination->initialize($config);
        
        $page            = (uri_custom()) ? uri_custom() : 0;
        $data['results'] = $this->parents_model->parentslist($config["per_page"], $page);
        $data["links"]   = $this->pagination->create_links();
        
        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/parents/list', $data);
        $this->load->view('admin/layout/dashboard_footer');
    }
    
    public function delete($id)
    {
        if ($id != '') {
            $user_id = $this->parents_model->get_user_id( $id );
            $delete_parent = '';
            if( $user_id ) {
                $delete_parent = $this->parents_model->delete( $id );
                $delete_parent_user_table = $this->user_model->delete( $user_id );
            }
            if ($delete_parent) {
                $this->session->set_flashdata('success_msg', 'Parent is deleted successfully.');
            } else {
                $this->session->set_flashdata('success_err', 'Some problems occured, please try again.');
            }
            redirect('admin/parents/parentslist');
        }
    }
    
    function check_parent_username( $user_name )
    {
        if ($this->input->post('user_id'))
            $id = $this->input->post('user_id');
        else
            $id = '';
        $result = $this->user_model->check_unique_parent_username($id, $user_name);
        if ($result == 0)
            $response = true;
        else {
            $this->form_validation->set_message('check_parent_username', 'Parent Name must be unique');
            $response = false;
        }
        return $response;
    }
}