<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teachers extends CI_Controller
{   
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('subjects_model');
    }
    
    function lists()
    {
        $header['title'] = 'Teachers list';
        $this->load->library('pagination');
        
        $config                = array();
        $config["base_url"]    = base_url() . "admin/user/teacherslist";
        $config["total_rows"]  = $this->user_model->record_count_type(4);
        $config["per_page"]    = 5;
        $config["uri_segment"] = 4;
        
        $config['full_tag_open']   = '<ul class="pagination">';
        $config['full_tag_close']  = '</ul>';
        $config['first_link']      = false;
        $config['last_link']       = false;
        $config['first_tag_open']  = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link']       = '&laquo';
        $config['prev_tag_open']   = '<li class="prev">';
        $config['prev_tag_close']  = '</li>';
        $config['next_link']       = '&raquo';
        $config['next_tag_open']   = '<li>';
        $config['next_tag_close']  = '</li>';
        $config['last_tag_open']   = '<li>';
        $config['last_tag_close']  = '</li>';
        $config['cur_tag_open']    = '<li class="active"><a href="#">';
        $config['cur_tag_close']   = '</a></li>';
        $config['num_tag_open']    = '<li>';
        $config['num_tag_close']   = '</li>';
        
        $this->pagination->initialize($config);
        
        $page            = (uri_custom()) ? uri_custom() : 0;
        $data['results'] = $this->user_model->userslist_type($config["per_page"], $page, 3);
        $data["links"]   = $this->pagination->create_links();
        
        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/teachers/list', $data);
        $this->load->view('admin/layout/dashboard_footer');
    }

    function details( $id )
    {
        $header['title'] = 'Teachers list';
        $this->load->model('teacher_subjects_model');     
        
        $data['results']  = $this->user_model->teacher_details( $id );
        $data['subjects'] = $this->subjects_model->subjectlist( NULL, NULL );
        $teacher_subjects = $this->teacher_subjects_model->teacher_subjects( $id );

        $data['subjects_names'] = $teacher_subjects[0]->subjects_names;
        $data['selected_subject_ids'] = explode(',', $teacher_subjects[0]->subject_ids );
        
        if(  $this->input->post( 'subjects_add' ) ) 
        {
            $subjects = $this->input->post( 'subjects' );
            $insert_teacher_subjects = $this->teacher_subjects_model->insert( $id, $subjects );
            
            if( $insert_teacher_subjects ) 
            {
                $this->session->set_flashdata('success_msg', 'Subjects added for teacher successfully.');
            } 
            else 
            {
                $this->session->set_flashdata('success_err', 'Some problems occured, please try again.');
            }
            ;
            //redirect_update_not_working();
        }

        $this->load->view('admin/layout/dashboard_header', $header);
        $this->load->view('admin/layout/dashboard_sidebar_menu');
        $this->load->view('admin/teachers/detail', $data);
        $this->load->view('admin/layout/dashboard_footer');
    }
}