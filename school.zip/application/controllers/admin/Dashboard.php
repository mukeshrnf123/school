<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct()
    {
		parent::__construct();
		$this->load->model( 'user_model' );
		$this->load->model( 'holidays_model' ); 
		$this->load->driver( 'cache' );
		//$this->load->library( 'widget' );  
           
    }

    function index() {
        $header['title']   = 'Dashboard';
        $header['script']  = 'true';

        $data['holidays']  = $this->holidays_model->holidays_dashboard();
        $data['usertypes'] = $this->user_model->usertypes_dashboard();

        $this->load->view( 'admin/layout/dashboard_header', $header );
        $this->load->view( 'admin/layout/dashboard_sidebar_menu' );
        $this->load->view( 'admin/dashboard/index', $data );
        $this->load->view( 'admin/layout/dashboard_footer' );		
    } 
}