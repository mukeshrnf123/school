<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sections extends CI_Controller {

    public function __construct()
    {
		parent::__construct();
        $this->load->model( 'sections_model' );
    }

	function add() 
	{
		$header['title'] = 'Sections Add';
		$this->load->library( 'form_validation' );
		$this->load->model( 'classes_model' );
		
        $this->form_validation->set_rules( 'section_name', 'Sections Name', 'trim|required|xss_clean|is_unique[tbl_classes.class_name]' );
        $this->form_validation->set_rules( 'class_id', 'Class', 'trim|required|xss_clean' );

		$sectionData = array(
			'section_name' => strip_tags( $this->input->post( 'section_name' ) ),
			'class_id'     => strip_tags( $this->input->post( 'class_id' ) ),
		);

		$data = array();
		$data['class_lists'] = $this->classes_model->classlists();
        if( $this->form_validation->run() == false ) 
        {
			$this->load->view( 'admin/layout/dashboard_header', $header );
			$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
			$this->load->view( 'admin/sections/add', $data );
			$this->load->view( 'admin/layout/dashboard_footer' );	
		} 
		else 
		{	
            $insert = $this->sections_model->insert($sectionData);
            if( $insert ) 
            {
                $this->session->set_flashdata('success_msg', 'Sections is added successfully.');
                redirect( 'admin/sections/sectionslist' );
            } 
            else 
            {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
	} 

    function edit() 
	{
		$header['title'] = 'Section Edit';
		$this->load->library( 'form_validation' );

		$this->load->model( 'classes_model' );
		$id = uri_custom();
        $this->form_validation->set_rules( 'section_name', 'Section Name', 'trim|required|xss_clean' );

		$sectionData = array(
			'section_name' => strip_tags( $this->input->post( 'section_name' ) ),
			'id'           => strip_tags( $this->input->post( 'id' ) ),
			'status'       => strip_tags( $this->input->post( 'status' ) ),
			'class_id'     => strip_tags( $this->input->post( 'class_id' ) ),
		);

		$data = array();
		$data['class_lists'] = $this->classes_model->classlists();
		$data['details'] = $this->sections_model->details( $id );
        if( $this->form_validation->run() == false ) 
        {
			$this->load->view( 'admin/layout/dashboard_header', $header );
			$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
			$this->load->view( 'admin/sections/edit', $data );
			$this->load->view( 'admin/layout/dashboard_footer' );	
		} 
		else 
		{	
            $insert = $this->sections_model->edit( $sectionData );
            if( $insert ) 
            {
                $this->session->set_flashdata('success_msg', 'Section is updated successfully.');
                redirect( 'admin/sections/sectionslist' );
            } 
            else 
            {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }
	}

	function sectionslist() 
	{
        $header['title'] = 'Sections lists';
        $this->load->library('pagination');
        
        $config = array();
        $config["base_url"] = base_url() . "admin/sections/sectionslist";
        $config["total_rows"] = $this->sections_model->record_count();
        $config["per_page"] = 5;
        $config["uri_segment"] = 4;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
		
        $this->pagination->initialize($config);

        $page = (uri_custom()) ? uri_custom() : 0;
       	$data['results']  = $this->sections_model->sectionslist( $config["per_page"], $page );
        $data["links"] = $this->pagination->create_links();

		$this->load->view( 'admin/layout/dashboard_header', $header );
		$this->load->view( 'admin/layout/dashboard_sidebar_menu' );
		$this->load->view('admin/sections/list', $data);
		$this->load->view( 'admin/layout/dashboard_footer' );
	}

	function delete( $id ) 
	{
		if( $id != '' ) 
		{
			$delete = $this->sections_model->delete( $id );
			if( $delete ) 
			{
				$this->session->set_flashdata('success_msg', 'Section is deleted successfully.');
			} 
			else 
			{
				$this->session->set_flashdata('success_err', 'Some problems occured, please try again.');
			}
			redirect( 'admin/sections/sectionslist' );
		}
	}
	
	function get_section_class_wise() 
	{
		$class_id = $this->input->post( 'class_id' );
		$get_section_lists = '';
		if( $class_id != '') 
		{
			$get_section_lists = $this->sections_model->get_section_class_wise( $class_id );
			echo json_encode($get_section_lists);die;
		} 
		return $get_section_lists;
	}

	function check_childrens() 
	{
		$this->load->model( 'parent_children_model' );
		$childrens = $this->input->post( 'childrens' );
		if( $childrens )
		{
			$check_children_lists = $this->parent_children_model->check_children_lists( $childrens );
			
			echo $count = count( json_decode($check_children_lists, true));die;
			
			/*if( $count > 0 )
			{
				return 'Please check the children list again. Children selected for another parent.';
			}
			else
			{
				return '';
			}*/
		}
		else
		{
			return false;		
		}
	}
}