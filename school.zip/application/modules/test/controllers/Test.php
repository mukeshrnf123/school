<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Test extends MX_Controller {

	function __construct() {
        parent::__construct();
    }

    public function index()
	{
		$this->load->view('test_view');
	}
}

/* End of file users.php */
/* Location: ./application/modules/users/controllers/users.php */