<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blocker {

    function requestBlocker() {
        
       if($_SERVER["REMOTE_ADDR"] != "::1"){
            echo "not allowed";
            die;
        }
    }
}