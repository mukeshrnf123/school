<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* to get the asset folder path */
if ( ! function_exists('asset_url()'))
{
	function asset_url()
	{
		return base_url().'assets/';
	}
}

/* to get the 4th parameter value */
if ( ! function_exists('uri_custom()'))
{
	function uri_custom() 
	{
		$ci =& get_instance();
		return $ci->uri->segment(4);
	}
}

/* to refresh current page*/
if ( ! function_exists('redirect_same_url' ) ) 
{	
	function redirect_same_url() 
	{
		$ci =& get_instance();
		return $ci->uri->uri_string();
	}
}

/* when update fields not working */
if ( ! function_exists('redirect_update_not_working' ) ) 
{	
	function redirect_update_not_working() 
	{
		return redirect(redirect_same_url(), 'refresh');
	}
}	