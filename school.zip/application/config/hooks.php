<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$hook['pre_controller'] = array(
        'class'    => 'Blocker',
        'function' => 'requestBlocker',
        'filename' => 'Blocker.php',
        'filepath' => 'hooks',
        'params'   => ""
);