<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="panel-default">
                <?php if ($this->session->flashdata('success_msg')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_msg') ?> </div>
                <?php } ?>
                <?php if ($this->session->flashdata('success_err')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_err') ?> </div>
                <?php } ?>
                
                <?php echo form_open('admin/sections/add/'); ?>
                
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Section Name</label>
                    <input type="text" name='section_name' class="form-control" id="inputSuccess" value="<?php echo set_value( 'section_name' ); ?>">
                    <?php echo form_error('section_name'); ?>
                </div>

                <div class="dropdown form-group has-success">
                    <select name="class_id" class='btn btn-default dropdown-toggle'>
                        <option value="">Select Class</option>
                        <?php foreach ($class_lists AS $class_list) { ?>
                        <option value="<?php echo $class_list->id;?>"><?php echo $class_list->class_name;?></option>
                        <?php } ?>
                    </select>
                    <?php echo form_error('class_id'); ?>
                </div>

                <input type="submit" name='blog_add' class="btn btn-default" value='Submit'>
                <button type="reset" class="btn btn-default">Reset Button</button>
                <?php echo form_close(); ?>

            </div>
        </div>
    </div>
</div>    