<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="panel-default">
                <?php echo form_open('admin/subjects/edit/'.$details->id); ?>
                
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Subject Name</label>
                    <input type="text" name='subject_name' class="form-control" id="inputSuccess" value="<?php echo $details->subject_name; ?>">
                     <?php echo form_error('subject_name'); ?>
                </div>

                <label class="control-label" for="inputSuccess">Status</label>
                <div class="radio">
                    <?php $status= $details->status; ?> 
                  <label><input type="radio" name="status" value="1" <?php echo ($status== '1') ?  "checked" : "" ;  ?>>Enabled</label>
                  <label><input type="radio" name="status" value="0>" <?php echo ($status== '0') ?  "checked" : "" ;  ?>>Disabled</label>
                </div>

                <input type='hidden' name='id' value="<?php echo $details->id; ?>">
               </div>
                <input type="submit" name='blog_add' class="btn btn-default" value='Submit'>
                
                <button type="reset" class="btn btn-default">Reset Button</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
