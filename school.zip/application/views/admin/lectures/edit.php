<?php
//echo '<pre>';print_r($details);die;
?>
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="panel-default">
                <?php echo form_open('admin/lectures/edit/'.$details->id); ?>
                
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Lecture Start</label>
                    <input type="text" name='lecture_start' class="form-control" id="inputSuccess" value="<?php echo $details->start; ?>">
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Lecture End</label>
                    <input type="text" name='lecture_end' class="form-control" id="inputSuccess" value="<?php echo $details->end; ?>">
                </div>


                <input type='hidden' name='id' value="<?php echo $details->id; ?>">
                   <input type="submit" name='lecture_edit' class="btn btn-default" value='Submit'>
                <button type="reset" class="btn btn-default">Reset Button</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>