<script type="text/javascript" src="<?php echo asset_url();?>js/jquery-ui.js"></script>
<link rel="stylesheet" href="<?php echo asset_url();?>css/jquery-ui.css">
<script type="text/javascript">
    jQuery( function() {
        jQuery( ".holiday_start, .holiday_end" ).datepicker();
    });
</script> 
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="panel-default">
                
                <?php if ($this->session->flashdata('success_msg')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_msg') ?> </div>
                <?php } ?>
                <?php if ($this->session->flashdata('success_err')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_err') ?> </div>
                <?php } ?>

                <?php $form_attributes = array('name' => 'holiday'); ?>
                <?php echo form_open('admin/holidays/add/',  $form_attributes); ?>
                
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Holiday Name</label>
                    <input type="text" name='holiday_name' class="form-control" id="inputSuccess" value="<?php echo set_value( 'holiday_name' ); ?>">
                    <?php echo form_error('holiday_name'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Holiday Start</label>
                    <input type="text" name='holiday_start' class="form-control holiday_start" id="inputSuccess" value="<?php echo set_value( 'holiday_start' ); ?>">                  
                    <?php echo form_error('holiday_start'); ?>
                </div>
                
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Holiday End</label>
                    <input type="text" name='holiday_end' class="form-control holiday_end" id="inputSuccess" value="<?php echo set_value( 'holiday_end' ); ?>">
                    <?php echo form_error('holiday_end'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Status</label> 
                      <label><input type="radio" name="status" value="1" checked='checked'>Enabled</label>
                      <label><input type="radio" name="status" value="0">Disabled</label>
                </div>

                <input type="submit" name='holiday_add' class="btn btn-default" value='Submit'>
                <button type="reset" class="btn btn-default">Reset Button</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>

