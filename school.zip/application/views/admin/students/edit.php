<?php //echo '<pre>';print_r($details);?>
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="panel-default">
                <?php if ($this->session->flashdata('success_msg')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_msg') ?> </div>
                <?php } ?>
                <?php if ($this->session->flashdata('success_err')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_err') ?> </div>
                <?php } ?>
                <?php echo form_open('admin/students/edit/'.$details->id); ?>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">User Name</label>
                    <input type="text" name='username' class="form-control" id="inputSuccess" value="<?php echo $details->username; ?>">
                    <?php echo form_error('username'); ?>
                </div>
            
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">First Name</label>
                    <input type="text" name='first_name' class="form-control" id="inputSuccess" value="<?php echo $details->first_name; ?>">
                    <?php echo form_error('first_name'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Last Name</label>
                    <input type="text" name='last_name' class="form-control" id="inputSuccess" value="<?php echo $details->last_name; ?>">
                    <?php echo form_error('last_name'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Email</label>
                    <input type="text" name='email' class="form-control" id="inputSuccess" value="<?php echo $details->email; ?>">
                    <?php echo form_error('email'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Mobile No.</label>
                    <input type="text" name='mobile' class="form-control" id="inputSuccess" value="<?php echo $details->mobile; ?>">
                    <?php echo form_error('mobile'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Password</label>
                    <input type="password" name='password' class="form-control" id="inputSuccess" value="">
                    <?php echo form_error('password'); ?>
                </div>

                <input type='hidden' name='id' value='<?php echo $details->id;?>'>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Class</label>
                    <select id='class_id' name="class_id" class='btn btn-default dropdown-toggle'>
                        <option value="">Select Class</option>
                        <?php foreach ($class_lists AS $class_list) { ?>
                        <option value="<?php echo $class_list->id;?>" <?php if($details->class_id == $class_list->id ) echo 'selected="selected"'; ?>><?php echo $class_list->class_name;?></option>
                        <?php } ?>
                    </select>
                    <?php echo form_error('class_id'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Section</label>
                    <select id='section_id' name="section_id" class='btn btn-default dropdown-toggle'>
                        <option value="">Select Section</option>
                    </select>
                    <?php echo form_error('class_id'); ?>
                </div>

               <input type="submit" name='student_edit' class="btn btn-default" value='Submit'>
                <button type="reset" class="btn btn-default">Reset Button</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
<script>
    <?php if($details->class_id != '') { ?>
        var class_id = <?php echo $details->class_id; ?>;
        jQuery.ajax({
            url: "<?php echo base_url(); ?>admin/sections/get_section_class_wise",
            type: "POST",
            contentType: "application/x-www-form-urlencoded",
            data: {class_id: class_id},
            dataType: "html",
            success: function(data ) {
                var obj={ Sections: JSON.parse(data)};
                if(obj != '') {
                    jQuery('select#section_id').empty();
                    for(var i=0;i<obj.Sections.length;i++)
                    {
                        var option=jQuery('<option value='+obj.Sections[i]['id']+'></option>').text(obj.Sections[i]['section_name']);
                        jQuery('select#section_id').append(option);
                    }
                    jQuery("select#section_id").val(<?php echo $details->section_id; ?>);
                }
            }
        });

    <?php } ?>

    jQuery("#class_id").change(function () {
        class_id = jQuery(this).val();
        jQuery.ajax({
            url: "<?php echo base_url(); ?>admin/sections/get_section_class_wise",
            type: "POST",
            contentType: "application/x-www-form-urlencoded",
            data: {class_id: class_id},
            dataType: "html",
            success: function(data ) {
                var obj={ Sections: JSON.parse(data)};
                if(obj != '') {
                    jQuery('select#section_id').empty();
                    for(var i=0;i<obj.Sections.length;i++)
                    {
                        var option=jQuery('<option value='+obj.Sections[i]['id']+'></option>').text(obj.Sections[i]['section_name']);
                        jQuery('select#section_id').append(option);
                    }
                }
            }
        });
    });
</script>        