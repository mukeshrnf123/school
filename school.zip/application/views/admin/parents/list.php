<?php //echo '<pre>';print_r($results);?>
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <?php if ($this->session->flashdata('success_msg')) { ?>
            <div class="alert alert-success"> <?php echo $this->session->flashdata('success_msg') ?> </div>
        <?php } ?>
        <?php if ($this->session->flashdata('success_err')) { ?>
            <div class="alert alert-success"> <?php echo $this->session->flashdata('success_err') ?> </div>
        <?php } ?>
         <a href="<?php echo base_url();?>admin/parents/add" class="btn btn-default">Add Parent</a>
        <div class="form-group pull-right">
            <input type="text" class="search form-control" id='search' placeholder="What you looking for?">
        </div>
        <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <td align="center">
                    <strong>S.no.</strong>
                </td>
                <td align="center">
                    <strong>Email</strong>
                </td>
                <td align="center">
                    <strong>User Name</strong>
                </td>
                <td align="center">
                    <strong>Parent Name</strong>
                </td>

                <td align="center">
                  <strong>Mobile</strong>
                </td>
                <td align="center">
                  <strong>Action </strong>
                </td>
              </tr>
            </thead>

            <tbody>
                <?php $i = $this->uri->segment(4)+1;// for serial no.
                    foreach($results as $result) { ?>
                        <tr> 
                            <td align="center"> <?php echo $i; ?> </td>
                            <td align="center"> <?php echo $result->email; ?> </td>
                            <td align="center"> <?php echo $result->username; ?> </td>
                            <td align="center"> <?php echo ucfirst($result->first_name) . ' ' . ucfirst($result->last_name); ?> </td>
                            <td align="center"> <?php echo $result->mobile; ?> </td>
                            <td align="center"> 
                                <a href="<?php echo base_url() . 'admin/user/edit/' . $result->id; ?>">Edit </a> /
                                <a href="<?php echo base_url() . 'admin/user/delete/' . $result->id; ?>"  onclick="return confirm('Are you sure you want to delete this item?');">Delete </a> 
                            </td>
                        </tr>
                <?php $i++; } ?>
            </tbody>
        </table>
        <p><?php echo $links; ?></p>
    </div>

<style> 
#search {
    width: 235px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

#search:focus {
    width: 100%;
}
</style>
