<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="panel-default">
                <?php if ($this->session->flashdata('success_msg')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_msg') ?> </div>
                <?php } ?>
                <?php if ($this->session->flashdata('success_err')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_err') ?> </div>
                <?php } ?>
                <?php echo form_open('admin/parents/add/'); ?>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">User Name</label>
                    <input type="text" name='user_name' class="form-control" id="inputSuccess" value="<?php echo set_value( 'user_name' ); ?>">
                    <?php echo form_error('user_name'); ?>
                </div>
            
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">First Name</label>
                    <input type="text" name='first_name' class="form-control" id="inputSuccess" value="<?php echo set_value( 'first_name' ); ?>">
                    <?php echo form_error('first_name'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Last Name</label>
                    <input type="text" name='last_name' class="form-control" id="inputSuccess" value="<?php echo set_value( 'last_name' ); ?>">
                    <?php echo form_error('last_name'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Email</label>
                    <input type="text" name='email' class="form-control" id="inputSuccess" value="<?php echo set_value( 'email' ); ?>">
                    <?php echo form_error('email'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Mobile No.</label>
                    <input type="text" name='mobile' class="form-control" id="inputSuccess" value="<?php echo set_value( 'mobile' ); ?>">
                    <?php echo form_error('mobile'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Password</label>
                    <input type="password" name='password' class="form-control" id="inputSuccess" value="<?php echo set_value( 'password' ); ?>">
                    <?php echo form_error('password'); ?>
                </div>

                <input type='hidden' name='role_id' value='2'>

               <input type="submit" name='blog_add' class="btn btn-default" value='Submit'>
                <button type="reset" class="btn btn-default">Reset Button</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>

