<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <?php if ($this->session->flashdata('success_msg')) { ?>
            <div class="alert alert-success"> <?php echo $this->session->flashdata('success_msg') ?> </div>
        <?php } ?>
        <?php if ($this->session->flashdata('success_err')) { ?>
            <div class="alert alert-success"> <?php echo $this->session->flashdata('success_err') ?> </div>
        <?php } ?>
        <a href="<?php echo base_url();?>admin/user/add" class="btn btn-success">Add User</a>
        <br><br>
       
        <table id="table" class="display" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>
<script type="text/javascript">
var table;
jQuery(document).ready(function() {
    table = jQuery('#table').DataTable({ 
        "processing": true, 
        "serverSide": true, 
        "bSort": true,
        "bAutoWidth": true,
        "order": [],
        "ajax": {
            "url": "<?php echo site_url('admin/users/ajax_list')?>",
            "type": "POST"
        },
        "columnDefs": [
        { 
            "targets": [ 0 ], 
            "orderable": false, 
        },
        ],
        "language": {
            searchPlaceholder: "What you looking for ?"
        },
        "aoColumns": [
            { bSortable: true, },
            { bSortable: true, },
            { bSortable: true, },
            { bSortable: true, },
            { bSortable: true, },
            {
                bSortable: false,
                mRender: function (data, type, row) { return '<a href="<?php echo base_url() ?>admin/user/edit/' + row[ 5 ] + '"><i class="ui-tooltip fa fa-pencil editor_edit" style="font-size: 22px;" data-original-title="Edit"></i></a> <a onclick="return confirm(\'Are you sure you want to delete this item?\');" href="<?php echo base_url() ?>admin/user/delete/' + row[ 5 ] + '"><i class="ui-tooltip fa fa-trash-o editor_remove" style="font-size: 22px;" data-original-title="Delete"></i></a>'; }
            }
    ]
    });
});

jQuery('#table th').each(function(index, th) {
    jQuery(th).unbind('click');
    jQuery(th).append('<button class="sort-btn btn-asc">&#9650;</button>');
    jQuery(th).append('<button class="sort-btn btn-desc">&#9660;</button>');

    jQuery(th).find('.btn-asc').click(function() {
        table.column(index).order('asc').draw();
    });
     
    jQuery(th).find('.btn-desc').click(function() {
        table.column(index).order('desc').draw();      
    }); 
});
</script>
