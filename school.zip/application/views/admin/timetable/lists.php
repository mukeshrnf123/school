<?php //echo '<pre>';print_r($results);?>
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <a href="<?php echo base_url();?>admin/timetable/add" class="btn btn-success">Add Timetable</a>
        <div class="form-group pull-right">
            <input type="text" class="search form-control" id='search' placeholder="What you looking for?">
        </div>
        <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <td align="center">
                    <strong>S.no.</strong>
                </td>
                <td align="center">
                    <strong>Teacher Name</strong>
                </td>
                <td align="center">
                    <strong>Lecture Time</strong>
                </td>
                <td align="center">
                    <strong>Day</strong>
                </td>
                <td align="center">
                  <strong>Action </strong>
                </td>
              </tr>
            </thead>
            <?php if(count($results) >= 1) { ?>
            <tbody>
                <?php $i = $this->uri->segment(4)+1;// for serial no.
                    foreach($results as $result) { ?>
                        <tr> 
                            <td align="center"> <?php echo $i; ?> </td>
                            <td align="center"> <?php echo ucwords( $result->teacher_name ); ?> </td>
                            <td align="center"> <?php echo $result->lecture; ?> </td>
                            <td align="center"> <?php echo $result->day; ?> </td>
                            <td align="center">   <a class='btn btn-sm btn-primary' href="<?php echo base_url() . 'admin/teachers/details/' . $result->id; ?>">Details </a>
                            </td>
                        </tr>
                <?php $i++; } ?>
            </tbody>
            <?php } ?>
        </table>
        <p><?php echo $links; ?></p>
    </div>

<style> 
#search {
    width: 235px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

#search:focus {
    width: 100%;
}
</style>