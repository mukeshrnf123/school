<?php //echo '<pre>';print_r($days);?>
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
                <div class="alert alert-danger customerror"></div>
                <div class="alert alert-success customsuccess"></div>
            </div>
            
        </div>
        
        <div class="col-lg-4">
            <div class="panel-default">
                <?php $form_attributes = array('name' => 'timetable', 'id' => 'timetable' ); ?>
                <?php echo form_open('admin/timetable/add/',  $form_attributes ); ?>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Teacher</label>
                    <select name="teacher_id" id='teacher_id' class='btn btn-default dropdown-toggle required'>
                        <option value="">Select Teacher</option>
                        <?php foreach ($teachers AS $teacher) { ?>
                        <option value="<?php echo $teacher->id;?>"><?php echo ucfirst( $teacher->first_name ) . ' ' . $teacher->last_name;?></option>
                        <?php } ?>
                    </select>
                    <?php echo form_error('teacher_id'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Class</label>
                    <select name="class_id" id='class_id' class='btn btn-default dropdown-toggle required'>
                        <option value="">Select Class</option>
                        <?php foreach ($classes AS $class) { ?>
                        <option value="<?php echo $class->id;?>"><?php echo $class->class_name ;?></option>
                        <?php } ?>
                    </select>
                    <?php echo form_error('class_id'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Section</label>
                    <select id='section_id' name="section_id" class='btn btn-default dropdown-toggle'>
                        <option value="">Select Section</option>
                    </select>
                    <?php echo form_error('class_id'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Lectures</label>
                    <select name="lecture_id" id='lecture_id' class='btn btn-default dropdown-toggle required'>
                        <option value="">Select Lectures</option>
                        <?php foreach ($lectures AS $lecture) { ?>
                        <option value="<?php echo $lecture->id;?>"><?php echo $lecture->start . ' to ' . $lecture->end;?></option>
                        <?php } ?>
                    </select>
                    <?php echo form_error('lecture_id'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Days</label>
                    <select name="day_id" id='day_id' class='btn btn-default dropdown-toggle required'>
                        <option value="">Select Days</option>
                        <?php foreach ($days AS $key => $value ) { ?>
                        <option value="<?php echo $key;?>"><?php echo $value;?></option>
                        <?php } ?>
                    </select>
                    <?php echo form_error('day_id'); ?>
                </div>

               <input type="submit" name='timetable_add' id='timetable_add' class="btn btn-default" value='Submit'>
                <button type="reset" class="btn btn-default">Reset Button</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script>
    jQuery().ready(function() {
        jQuery("#timetable").validate();
    });
    var cct = jQuery.cookie("<?php echo $this->config->item("csrf_cookie_name"); ?>");
    
    jQuery(".customerror").hide();
    jQuery(".customsuccess").hide();
    
    jQuery(".dropdown-toggle").change(function(){
        jQuery(".customerror").hide();
        jQuery(".customsuccess").hide();
    });

    jQuery("#class_id").change(function () 
    {
        class_id = jQuery(this).val();
        jQuery.ajax({
            url: "<?php echo base_url(); ?>admin/sections/get_section_class_wise",
            type: "POST",
            contentType: "application/x-www-form-urlencoded",
            data: {class_id: class_id, '<?php echo $this->security->get_csrf_token_name(); ?>': cct},
            dataType: "html",
            success: function(data ) {
                var obj={ Sections: JSON.parse(data)};
                if(obj != '') {
                    jQuery('select#section_id').empty();
                    for(var i=0;i<obj.Sections.length;i++)
                    {
                        var option=jQuery('<option value='+obj.Sections[i]['id']+'></option>').text(obj.Sections[i]['section_name']);
                        jQuery('select#section_id').append(option);
                    }
                }
            }
        });
    });

    jQuery("#timetable_add").click(function () 
    {

        teacher_id = jQuery("#teacher_id").val();
        class_id   = jQuery("#class_id").val();
        section_id = jQuery("#section_id").val();
        lecture_id = jQuery("#lecture_id").val();
        day_id     = jQuery("#day_id").val();
        
        if( teacher_id == '' || class_id == '' || section_id == '' || lecture_id == '' || day_id == '' )
        {
            jQuery(".customerror").text('Please select all the fields.').show();           
        }
        else
        {
            jQuery.ajax({
                url: "<?php echo base_url(); ?>admin/timetable/check_timetable",
                type: "POST",
                contentType: "application/x-www-form-urlencoded",
                data: {class_id: class_id, teacher_id: teacher_id, section_id: section_id, lecture_id: lecture_id, lecture_id: lecture_id, day_id: day_id, csrf_test_name: jQuery.cookie('csrf_cookie_name')},
                dataType: "html",
                success: function(data ) {
                    if( data == 'success' )
                    {
                        jQuery(".customsuccess").text('Record save successfully.').show();
                    }
                    else if( data == 'error1' )
                    {
                        jQuery(".customerror").text('Teacher and class is busy with this time slot.').show();
                    }
                    else if( data == 'error2' )
                    {
                        jQuery(".customerror").text('Class is busy with this time slot.').show();
                    }
                    else
                    {
                        jQuery(".customerror").text('Teacher is busy with this time slot.').show();
                    }
                }
            });
        } 
        return false;
    });   

</script>