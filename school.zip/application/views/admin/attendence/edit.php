<script type="text/javascript" src="<?php echo asset_url();?>js/CalendarPopup.js"></script>
<script type="text/javascript">
    var cal = new CalendarPopup();
</script> 
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="panel-default">
                <?php $form_attributes = array('name' => 'holiday'); ?>
                <?php echo form_open('admin/holidays/edit/'.$details->id,  $form_attributes); ?>
                
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Holiday Name</label>
                    <input type="text" name='holiday_name' class="form-control" id="inputSuccess" value="<?php echo $details->holiday_name; ?>">
                     <?php echo form_error('holiday_name'); ?>
                </div>
                
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Holiday Start</label>
                    <input type="text" name='holiday_start' class="form-control" id="inputSuccess" value="<?php echo $details->holiday_start; ?>">
                    <?php echo form_error('holiday_start'); ?>
                    <a href="#" onClick="cal.select(document.forms['holiday'].holiday_start,'anchor1','yyyy-MM-dd'); return false;" name="anchor1" id="anchor1"> (mm/dd/yyyy) Select</a>
                </div>
                
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Holiday End</label>
                    <input type="text" name='holiday_end' class="form-control" id="inputSuccess" value="<?php echo $details->holiday_end; ?>">
                    <a href="#" onClick="cal.select(document.forms['holiday'].holiday_end,'anchor1','yyyy-MM-dd'); return false;" name="anchor1" id="anchor1"> (mm/dd/yyyy) Select</a>
                    <?php echo form_error('holiday_end'); ?>
                </div>

                <label class="control-label" for="inputSuccess">Status</label>
                <div class="radio">
                    <?php $status= $details->status; ?> 
                  <label><input type="radio" name="status" value="1" <?php echo ($status== '1') ?  "checked" : "" ;  ?>>Enabled</label>
                  <label><input type="radio" name="status" value="0>" <?php echo ($status== '0') ?  "checked" : "" ;  ?>>Disabled</label>
                </div>

                <input type='hidden' name='id' value="<?php echo $details->id; ?>">
               </div>
                <input type="submit" name='blog_add' class="btn btn-default" value='Submit'>
                
                <button type="reset" class="btn btn-default">Reset Button</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
