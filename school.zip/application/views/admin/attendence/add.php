<script type="text/javascript" src="<?php echo asset_url();?>js/jquery-ui.js"></script>
<link rel="stylesheet" href="<?php echo asset_url();?>css/jquery-ui.css">
<script type="text/javascript">
    jQuery( function() {
        jQuery( "#attendence_date" ).datepicker( { dateFormat: 'dd-mm-yy' } ).datepicker("setDate", "0");;
    });
</script>
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="panel-default">
                
                <?php if ($this->session->flashdata('success_msg')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_msg') ?> </div>
                <?php } ?>
                <?php if ($this->session->flashdata('success_err')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_err') ?> </div>
                <?php } ?>

                <?php $form_attributes = array('name' => 'holiday'); ?>
                
                <div class="dropdown form-group has-success">
                    <label class="control-label" for="inputSuccess">Class</label>
                    <select name="class_id" id='class_id' class='btn btn-default dropdown-toggle'>
                        <option value="">Select Class</option>
                        <?php foreach ($class_lists AS $class_list) { ?>
                        <option value="<?php echo $class_list->id;?>"><?php echo $class_list->class_name;?></option>
                        <?php } ?>
                    </select>
                </div>                    
                    
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Section</label>
                    <select id='section_id' name="section_id" class='btn btn-default dropdown-toggle'>
                        <option value="">Select Section</option>
                    </select>
                </div>
                    
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Attendence Date</label>
                    <input type="text" name='attendence_date' class="form-control" id="attendence_date" value="">
                </div>

                <input type="submit" id='attendence_add' name='attendence_add' class="btn btn-default" value='Submit'>
                <button type="reset" class="btn btn-default">Reset Button</button>
                
            </div>
            <div class="container" id='students_container'>
                <center>
                   <h2>Students list</h2>
                </center>
                <?php $form_attributes = array( 'name' => 'attendence', 'id' => 'attendence' ); ?>
                <?php echo form_open('admin/attendence/add/',  $form_attributes); ?>
                <table id='students' class="table table-bordered" style="width: 70%;">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Present</th>                            
                            <th>Absent</th>
                            <th>Halfday</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <input type="submit" class="btn btn-default" id='attendence_submit' value="Submit">
                <?php echo form_close(); ?>
            </div>
        </div>

    </div>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script>
    var cct = jQuery.cookie("<?php echo $this->config->item("csrf_cookie_name"); ?>");
    jQuery("tr:has(td)").remove();
    jQuery("#students_container").hide();
    jQuery(".alert-success").fadeOut(5000);
    
    jQuery("#class_id").change(function () 
    {
        class_id = jQuery(this).val();
        jQuery.ajax({
            url: "<?php echo base_url(); ?>admin/sections/get_section_class_wise",
            type: "POST",
            contentType: "application/x-www-form-urlencoded",
            data: {class_id: class_id, '<?php echo $this->security->get_csrf_token_name(); ?>': cct},
            dataType: "html",
            success: function(data ) {
                var obj={ Sections: JSON.parse(data)};
                if(obj != '') {
                    jQuery('select#section_id').empty();
                    for(var i=0;i<obj.Sections.length;i++)
                    {
                        var option=jQuery('<option value='+obj.Sections[i]['id']+'></option>').text(obj.Sections[i]['section_name']);
                        jQuery('select#section_id').append(option);
                    }
                }
            }
        });
    });
    
    jQuery("#attendence_add").click(function () 
    {
        section_id = jQuery('#section_id').val();
        attendence_date = jQuery('#attendence_date').val();

        if( section_id != '' && attendence_date != '' )
        {
            jQuery.ajax({
                url: "<?php echo base_url(); ?>admin/students/get_students_by_section",
                type: "POST",
                contentType: "application/x-www-form-urlencoded",
                data: {
                    section_id: section_id, 
                    attendence_date: attendence_date, 
                    '<?php echo $this->security->get_csrf_token_name(); ?>': cct
                },
                dataType: "html",
                success: function(data ) 
                {
                    jQuery("#students_container").show('slow');
                    jQuery("tr:has(td)").remove();
                    var data = { 
                        "students" : JSON.parse(data) 
                    }
                    jQuery(data.students).each(function(index, element)
                    {  
                        if( typeof element['attendence'] != 'undefined' ) 
                        {                            
                            jQuery('#students').append('<tr><td width="20px"> '+element['id']+' </td> <td width="30px"> '+element['name']+' </td><td> <input type="radio" class="attendence_radio block" name="attendence_'+element['id']+'_section_'+element['section_id']+'_edit_1" value="1" ' + (element['attendence'] == 1 ? 'checked': '') + '></td><td> <input type="radio" class="block attendence_radio" name="attendence_'+element['id']+'_section_'+element['section_id']+'_edit_1" value="2" ' + (element['attendence'] == 2 ? 'checked': '') + '></td><td> <input type="radio" class="block attendence_radio" name="attendence_'+element['id']+'_section_'+element['section_id']+'_edit_1" value="3" ' + (element['attendence'] == 3 ? 'checked': '') + '></td></tr>');
                        }
                        else
                        {
                            jQuery('#students').append('<tr><td width="20px"> '+element['id']+' </td> <td width="30px"> '+element['name']+' </td><td> <input type="radio" class="attendence_radio block" name="attendence_'+element['id']+'_section_'+element['section_id']+'_edit_0" value="1" checked></td><td> <input type="radio" class="block attendence_radio" name="attendence_'+element['id']+'_section_'+element['section_id']+'_edit_0" value="2"></td><td> <input type="radio" class="block attendence_radio" name="attendence_'+element['id']+'_section_'+element['section_id']+'_edit_0" value="3"></td></tr>');
                        }
                               
                    })                                        
                }
            });
        }        
        else
        {
            alert('Please select all the fields.');
        }
    });
</script> 
<style>
td{
    border:1px solid #000;
}

tr td:nth-last-child(1){
    width:1%;
    white-space:nowrap;
}
tr td:nth-last-child(2){
    width:1%;
    white-space:nowrap;
}
tr td:nth-last-child(3){
    width:1%;
    white-space:nowrap;
}
</style>

