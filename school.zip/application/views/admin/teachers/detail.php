<?php //echo '<pre>';print_r($selected_subjects);?>
<div id="page-wrapper">
   <div class="container-fluid">

      <br>
      <div class="container">
        
        <?php if ($this->session->flashdata('success_msg')) { ?>
            <div class="alert alert-success"> <?php echo $this->session->flashdata('success_msg') ?> </div>
        <?php } ?>
        <?php if ($this->session->flashdata('success_err')) { ?>
            <div class="alert alert-success"> <?php echo $this->session->flashdata('success_err') ?> </div>
        <?php } ?>

         <div class="row">
            <div class="col-md-9">
               <div class="panel panel-default">
                  <div class="panel-body">
                     <div class="row">
                        <div class="col-md-12 lead">
                           Teacher profile
                           <hr>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-4 text-center">
                           <img class="img-circle avatar avatar-original" style="-webkit-user-select:none; 
                              display:block; margin:auto;" src="<?php echo asset_url();?>images/no.png">
                        </div>
                        <div class="col-md-8">
                           <div class="row">
                              <div class="col-md-12">
                                 <h1 class="only-bottom-margin"><?php echo ucwords( $results->first_name.' '.$results->last_name );?></h1>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-6">
                                 <span class="text-muted">Email:</span> <?php echo $results->email;?><br>
                                 <span class="text-muted">Birth date:</span> <?php echo $results->dob;?><br>
                                 <span class="text-muted">Gender:</span> <?php echo $results->gender;?><br>
                                 <span class="text-muted">Subjects:</span> <?php echo $subjects_names;?>
                                 <br><br>
                                 <small class="text-muted">Created: <?php echo $results->created;?></small>
                              </div>
                              <div class="col-md-6">
                                 <div class="activity-mini">
                                    <i class="glyphicon glyphicon-comment text-muted"></i> 500
                                 </div>
                                 <div class="activity-mini">
                                    <i class="glyphicon glyphicon-thumbs-up text-muted"></i> 1500
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-12">
                           <hr>
                           <button id='add_edit' class="btn btn-success pull-right"><i class="glyphicon glyphicon-pencil"></i> Add / Edit Subjects</button>
                        </div>
                     </div>
                     <?php echo form_open('admin/teachers/details/' . $results->id); ?>
                     <div id='subjects'>
                        <div class="checkbox">
                           <?php foreach($subjects AS $subject) { 
                              $checked = '';
                              if( in_array( $subject->id, $selected_subject_ids ) )
                              {
                                $checked = 'checked = "checked"';
                              }
                           ?>
                              <label><input type="checkbox" name='subjects[]' value="<?php echo $subject->id;?>" <?php echo $checked; ?>><?php echo $subject->subject_name;?></label>
                           <?php } ?>                           
                        </div>
                        <input type="submit" name='subjects_add' class="btn btn-success" value='Submit'>
                        <button type="reset" class="btn btn-success">Reset Button</button>
                     </div> 
                     <?php echo form_close(); ?>  
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<script>
   jQuery(document).ready(function(){
      jQuery("#subjects").hide();
       jQuery("#add_edit").click(function(){
           jQuery("#subjects").show("slow");
       });
   });
</script>