<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<?php 
		$ci = get_instance(); // CI_Loader instance
	?>
	<title><?php echo $ci->config->item('application_name') . ' - ' . $title; ?></title>

	<link rel="stylesheet" href="<?php echo asset_url();?>css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo asset_url();?>css/login.css">
	<link href="<?php echo asset_url();?>/font-awesome/css/font-awesome.css" rel="stylesheet">

	<script src='<?php echo asset_url();?>js/jquery.js'></script>
	<script src='<?php echo asset_url();?>js/bootstrap.js'></script>
	<script src='<?php echo asset_url();?>js/admin/login.js'></script>

</head>
<body>