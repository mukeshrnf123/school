<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
    <?php if ($this->session->flashdata('success_profile_update')) { ?>
        <div class="alert alert-success"> <?php echo $this->session->flashdata('success_profile_update') ?> </div>
    <?php } ?>
        <div class="col-lg-6"> 
    

    <?php echo form_open_multipart('admin/user/profile/'); ?>
        <div class="form-group has-success">
            <label class="control-label" for="inputSuccess">Username</label>
            <input type="text" name='username' class="form-control" id="inputSuccess" value="<?php echo $userinfo->username;?>" readonly>
        </div>

        <div class="form-group has-success">
            <label class="control-label" for="inputSuccess">Email</label>
            <input type="text" name='email' class="form-control" id="inputSuccess" value="<?php echo $userinfo->email;?>">
        </div>

        <div class="form-group has-success">
            <label class="control-label" for="inputSuccess">Password</label>
            <input type="password" name='password' class="form-control" id="inputSuccess">
        </div>

        <div class="form-group has-success">
            <label class="control-label" for="inputSuccess">Profile Image</label>
            <input type="file" name="userfile" size="20" />
        </div>

        <input type="submit" name='profile_update' class="btn btn-default" value='Submit'>
        <button type="reset" class="btn btn-default">Reset Button</button>
   <?php echo form_close(); ?>
</div></div></div>