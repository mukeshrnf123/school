<script src="<?php echo asset_url();?>js/bootstrap-multiselect.js"></script>
<link rel="stylesheet" href="<?php echo asset_url();?>css/bootstrap-multiselect.css">
<div id="page-wrapper">
   <div class="container-fluid">
      <div class="row">
         <div class="col-lg-12">
            <h1 class="page-header">
               <?php echo $title;?> 
            </h1>
         </div>
      </div>
      <div class="col-lg-4">
         <div class="panel-default">
            <?php if ($this->session->flashdata('success_msg')) { ?>
            <div class="alert alert-success"> <?php echo $this->session->flashdata('success_msg') ?> </div>
            <?php } ?>
            <?php if ($this->session->flashdata('success_err')) { ?>
            <div class="alert alert-success"> <?php echo $this->session->flashdata('success_err') ?> </div>
            <?php } ?>
            <?php $attributes = array('id'=>'child_form_id', 'name' => 'child_form_id' )?>
            <?php echo form_open( 'admin/user/childrens/'.$this->uri->segment(4), $attributes ); ?>
            <div class="form-group has-success">
               <a href="javascript:void(0)" id='add_children' class="btn btn-default">Add Children</a>
            </div>
            <div class="form-group has-success" id='class_hide' >
               <label class="control-label" for="inputSuccess">Class</label>
               <div class="dropdown form-group has-success">
                  <select id='class_id' name="class_id" class='btn btn-default dropdown-toggle'>
                     <option value="">Select Class</option>
                     <?php foreach ($class_lists AS $class_list) { ?>
                     <option value="<?php echo $class_list->id;?>"><?php echo $class_list->class_name;?></option>
                     <?php } ?>
                  </select>
                  <?php echo form_error('class_id'); ?>
               </div>
            </div>
            <div class="form-group has-success" id='section_hide' >
               <label class="control-label" for="inputSuccess">Section</label>
               <div class="dropdown form-group has-success">
                  <select id='section_id' name="section_id" class='btn btn-default dropdown-toggle'>
                     <option value="">Select Section</option>
                  </select>
                  <?php echo form_error('section_id'); ?>
               </div>
            </div>
            <div class="form-group has-success" id='children_hide' >
               <label class="control-label" for="inputSuccess">Select Children</label>
               <div class="dropdown form-group has-success">
                  <select id='children_id' multiple = 'multiple' name="children_id" class='btn btn-default dropdown-toggle'>
                  </select>
                  <input type='hidden' name='childrens' value='' id='childrens'>
                  <?php echo form_error('children_id'); ?>
               </div>
            </div>
            <div id='childern_selected'></div>
         </div>
         <div id='buttons'>
            <input type="button" name='children_add' id='check' class="btn btn-default" value='Submit'>
            <button type="reset" class="btn btn-default">Reset Button</button>
         </div>
         <?php echo form_close(); ?>
      </div>
   </div>
   <?php if(count($children_lists) >= 1) { ;?>
   <table class="table table-bordered table-striped">
      <thead>
         <tr>
            <td align="center">
               <strong>S.no.</strong>
            </td>
            <td align="center">
               <strong>Name</strong>
            </td>
            <td align="center">
               <strong>Email</strong>
            </td>
            <td align="center">
               <strong>Mobile</strong>
            </td>
            <td align="center">
               <strong>Class</strong>
            </td>
            <td align="center">
               <strong>Action </strong>
            </td>
         </tr>
      </thead>
      <tbody>
         <?php $i = 1;// for serial no.
            foreach($children_lists as $result) { ?>
         <tr>
            <td align="center"> <?php echo $i; ?> </td>
            <td align="center"> <?php echo $result->first_name . ' ' . $result->last_name ?> </td>
            <td align="center"> <?php echo $result->email; ?> </td>
            <td align="center"> <?php echo $result->mobile; ?> </td>
            <td align="center"> <?php echo $result->class_name . ' ( ' . $result->section_name.' )'; ?> </td>
            <td align="center"> 
               <?php $parent_id = $this->uri->segment(4);?>
               <a class='btn btn-sm btn-danger' href="<?php echo base_url() . 'admin/user/delete_child/' . $result->id .'/'. $parent_id; ?>"  onclick="return confirm('Are you sure you want to delete this children ?');">Delete </a> 
            </td>
         </tr>
         <?php $i++; } ?>
      </tbody>
   </table>
   <?php } ?>
</div>
<script>
   jQuery(document).ready(function() 
   {
       jQuery('#class_hide').hide();
       jQuery('#section_hide').hide();
       jQuery('#children_hide').hide();
       jQuery('#buttons').hide();
       
       jQuery("#add_children").click(function () 
       {
           jQuery('#class_hide').show('slow');
       }); 
   
       jQuery(function() 
       {
           jQuery('#children_id').multiselect({
               includeSelectAllOption: true
           });
       });  
   
       jQuery("#check").click(function()
       {
           var childrens = [];
           
           jQuery.each(jQuery("#children_id option:selected"), function()
           {            
               childrens.push(jQuery(this).val());
           });
   
           jQuery("#childrens").val(childrens.join(","));
   
           jQuery.ajax({
               url: "<?php echo base_url(); ?>admin/sections/check_childrens",
               type: "POST",
               contentType: "application/x-www-form-urlencoded",
               data: {childrens: childrens.join(",")},
               dataType: "html",
               success: function( data ) 
               {
                   if( data > 0 )
                   {
                       jQuery('#childern_selected').text('Please check the children list again. Children already selected.');
                       jQuery('#child_form_id').attr('onsubmit','return false;');
                   }    
                   else
                   {
                       document.getElementById('child_form_id').submit();
                   }
               }
           });
       });
   
       jQuery("#class_id").change(function () 
       {
           jQuery('#section_hide').show('slow');
           jQuery('#childern_selected').text('');
   
           class_id = jQuery(this).val();
           jQuery.ajax({
               url: "<?php echo base_url(); ?>admin/sections/get_section_class_wise",
               type: "POST",
               contentType: "application/x-www-form-urlencoded",
               data: {class_id: class_id},
               dataType: "html",
               success: function(data ) 
               {
                   var sections = JSON.parse(data);
                   jQuery('#section_id').empty();
                   jQuery('#section_id').html('<option value="">Select Section</option>');
                   for(var c in sections) 
                   {
                       document.getElementById('section_id').innerHTML += '<option value="' + sections[c].id +'">' + sections[c].section_name + '</option>';
                   }
               }
           });
       });
       jQuery("#section_id").change(function () 
       {
           jQuery('#children_hide').show('slow');
           jQuery('#childern_selected').text('');
           jQuery('#buttons').show();
           section_id = jQuery(this).val();
           parent_id  = <?php echo uri_custom();?>;
           jQuery.ajax({
               url: "<?php echo base_url(); ?>admin/user/get_students_section_wise",
               type: "POST",
               contentType: "application/x-www-form-urlencoded",
               data: {section_id: section_id, parent_id: parent_id},
               dataType: "html",
               success: function(data ) 
               {
                   var obj = { Childrens: JSON.parse(data)};
                   jQuery('#children_id').empty();
                   for(var i = 0; i < obj.Childrens.length; i++)
                   {
                       var option = jQuery('<option value='+obj.Childrens[i]['id']+'></option>').text(obj.Childrens[i]['first_name']);
                       jQuery('select#children_id').append(option);
                   }
                   jQuery('#children_id').multiselect('rebuild');
               }
           });
       });
   });
</script>