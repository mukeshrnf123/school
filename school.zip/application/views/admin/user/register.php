
<center><h1>Welcome to CodeIgniter!</h1>
<?php echo validation_errors(); ?></center>
<?php
	if(!empty($error_msg)){
        echo '<p class="statusMsg">'.$error_msg.'</p>';
    }
?>
<div class="container">
	<div class="omb_login">
    	<h3 class="omb_authTitle"><a href="<?php echo site_url(); ?>/admin/user/login">Login </a>or Sign up</h3>
		<div class="row omb_row-sm-offset-3 omb_socialButtons">
    	    <div class="col-xs-4 col-sm-2">
		        <a href="#" class="btn btn-lg btn-block omb_btn-facebook">
			        <i class="fa fa-facebook visible-xs"></i>
			        <span class="hidden-xs">Facebook</span>
		        </a>
	        </div>
        	<div class="col-xs-4 col-sm-2">
		        <a href="#" class="btn btn-lg btn-block omb_btn-twitter">
			        <i class="fa fa-twitter visible-xs"></i>
			        <span class="hidden-xs">Twitter</span>
		        </a>
	        </div>	
        	<div class="col-xs-4 col-sm-2">
		        <a href="#" class="btn btn-lg btn-block omb_btn-google">
			        <i class="fa fa-google-plus visible-xs"></i>
			        <span class="hidden-xs">Google+</span>
		        </a>
	        </div>	
		</div>

		<div class="row omb_row-sm-offset-3 omb_loginOr">
			<div class="col-xs-12 col-sm-6">
				<hr class="omb_hrOr">
				<span class="omb_spanOr">or</span>
			</div>
		</div>

		<div class="row omb_row-sm-offset-3">
			<div class="col-xs-12 col-sm-6">	
			    <form class="omb_loginForm" action="" autocomplete="off" method="POST">
					<div class="input-group">
						<span class="input-group-addon"><i class="fa fa-user"></i></span>
						<input type="text" class="form-control" name="username" value="<?php echo set_value('username'); ?>" placeholder="Username"> 
					</div>
					<span class="help-block"></span>
										
					<div class="input-group">
						<span class="input-group-addon"><i class="fa fa-lock"></i></span>
						<input  type="text" class="form-control" name="email" value="<?php echo set_value('email'); ?>" placeholder="Email">
					</div>
                    <span class="help-block"></span>

					<div class="input-group">
						<span class="input-group-addon"><i class="fa fa-lock"></i></span>
						<input  type="password" class="form-control" name="password" value="<?php echo set_value('password'); ?>" placeholder="Password">
					</div>
                    <span class="help-block"></span>

					<div class="input-group">
						<span class="input-group-addon"><i class="fa fa-lock"></i></span>
						<input  type="password" class="form-control" name="repassword" value="<?php echo set_value('repassword'); ?>" placeholder="Re-Password">
					</div>
                    <span class="help-block"></span>

					<button class="btn btn-lg btn-primary btn-block" type="submit">Register</button>
				</form>
			</div>
    	</div>    	
	</div>
</div>