<script type="text/javascript" src="<?php echo asset_url();?>js/jquery-ui.js"></script>
<link rel="stylesheet" href="<?php echo asset_url();?>css/jquery-ui.css">
<script type="text/javascript">
    jQuery( function() {
        jQuery( "#dob" ).datepicker();
    });
</script>  
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="panel-default">
                <?php if ($this->session->flashdata('success_msg')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_msg') ?> </div>
                <?php } ?>
                <?php if ($this->session->flashdata('success_err')) { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success_err') ?> </div>
                <?php } ?>
                <?php $form_attributes = array('name' => 'user'); ?>
                <?php echo form_open('admin/user/edit/'.$details->id,  $form_attributes ); ?>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Gender</label>
                    <div class="checkbox">
                        <?php $gender= $details->gender; ?>
                        <label><input type="radio" name="gender" value="1" <?php echo ($gender== '1') ?  "checked" : "" ;  ?>>Male</label>
                        <label><input type="radio" name="gender" value="2>" <?php echo ($gender== '2') ?  "checked" : "" ;  ?>>Female</label>
                    </div>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">User Name</label>
                    <input type="text" name='username' class="form-control" id="inputSuccess" value="<?php echo $details->username; ?>">
                    <?php echo form_error('username'); ?>
                </div>
            
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">First Name</label>
                    <input type="text" name='first_name' class="form-control" id="inputSuccess" value="<?php echo $details->first_name; ?>">
                    <?php echo form_error('first_name'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Last Name</label>
                    <input type="text" name='last_name' class="form-control" id="inputSuccess" value="<?php echo $details->last_name; ?>">
                    <?php echo form_error('last_name'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Email</label>
                    <input type="text" name='email' class="form-control" id="inputSuccess" value="<?php echo $details->email; ?>">
                    <?php echo form_error('email'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Mobile No.</label>
                    <input type="text" name='mobile' class="form-control" id="inputSuccess" value="<?php echo $details->mobile; ?>">
                    <?php echo form_error('mobile'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Password</label>
                    <input type="password" name='password' class="form-control" id="inputSuccess" value="">
                    <?php echo form_error('password'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Role</label>
                    <select name="role_id" class='btn btn-default dropdown-toggle'>
                        <option value="">Select Role</option>
                        <?php foreach ($roles AS $role) { ?>
                        <option value="<?php echo $role->id;?>" <?php if($details->role_id == $role->id ) echo 'selected="selected"'; ?> ><?php echo $role->role_name;?></option>
                        <?php } ?>
                    </select>
                    <?php echo form_error('role_id'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Status</label>
                        <?php $status= $details->status; ?> 
                      <label><input type="radio" name="status" value="1" <?php echo ($status== '1') ?  "checked" : "" ;  ?>>Enabled</label>
                      <label><input type="radio" name="status" value="0>" <?php echo ($status== '0') ?  "checked" : "" ;  ?>>Disabled</label>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">DOB</label>
                    <?php
                        $dob_from_db = explode('-', $details->dob);
                        $dob = $dob_from_db[1].'/'.$dob_from_db[2].'/'.$dob_from_db[0];
                    ?>
                    <input type="text" name='dob' class="form-control" id="dob" value="<?php echo $dob; ?>">
                   
<?php echo form_error('dob'); ?>
                </div>

                <input type='hidden' name='id' value='<?php echo $details->id;?>'>

               <input type="submit" name='blog_add' class="btn btn-default" value='Submit'>
                <button type="reset" class="btn btn-default">Reset Button</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>

