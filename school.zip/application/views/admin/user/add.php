<?php //echo '<pre>';print_r($details);?>
<script type="text/javascript" src="<?php echo asset_url();?>js/CalendarPopup.js"></script>
<script type="text/javascript">
    var cal = new CalendarPopup();
</script>  
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php echo $title;?> 
                </h1>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="panel-default">
                <?php $form_attributes = array('name' => 'user'); ?>
                <?php echo form_open('admin/user/add/',  $form_attributes ); ?>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Gender</label>
                    <div class="checkbox">
                        <label><input type="radio" name="gender" value="1" checked="checked" >Male</label>
                        <label><input type="radio" name="gender" value="2>">Female</label>
                    </div>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">User Name</label>
                    <input type="text" name='username' class="form-control" id="inputSuccess" value="<?php echo set_value('username'); ?>">
                    <?php echo form_error('username'); ?>
                </div>
            
                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">First Name</label>
                    <input type="text" name='first_name' class="form-control" id="inputSuccess" value="<?php echo set_value('first_name'); ?>">
                    <?php echo form_error('first_name'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Last Name</label>
                    <input type="text" name='last_name' class="form-control" id="inputSuccess" value="<?php echo set_value('last_name'); ?>">
                    <?php echo form_error('last_name'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Email</label>
                    <input type="text" name='email' class="form-control" id="inputSuccess" value="<?php echo set_value('email'); ?>">
                    <?php echo form_error('email'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Mobile No.</label>
                    <input type="text" name='mobile' class="form-control" id="inputSuccess" value="<?php echo set_value('mobile'); ?>">
                    <?php echo form_error('mobile'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Password</label>
                    <input type="password" name='password' class="form-control" id="inputSuccess" value="">
                    <?php echo form_error('password'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Role</label>
                    <select name="role_id" id='role_id' class='btn btn-default dropdown-toggle'>
                        <option value="">Select Role</option>
                        <?php foreach ($roles AS $role) { ?>
                        <option value="<?php echo $role->id;?>"><?php echo $role->role_name;?></option>
                        <?php } ?>
                    </select>
                    <?php echo form_error('role_id'); ?>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">DOB</label>
                    <input type="text" name='dob' class="form-control" id="dob" value="<?php echo set_value('dob'); ?>">
                    <a href="#" onClick="cal.select(document.forms['user'].dob,'anchor1','MM/dd/yyyy'); return false;" name="anchor1" id="anchor1"> (mm/dd/yyyy) Select</a>
                    <?php echo form_error('dob'); ?>
                </div>

                <div class="form-group has-success">
                    <div id='changed_result'></div>
                </div>

                <div class="form-group has-success">
                    <label class="control-label" for="inputSuccess">Status</label>
                      <label><input type="radio" name="status" value="1" checked="checked">Enabled</label>
                      <label><input type="radio" name="status" value="0>">Disabled</label>
                </div>

               <input type="submit" name='blog_add' class="btn btn-default" value='Submit'>
                <button type="reset" class="btn btn-default">Reset Button</button>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>